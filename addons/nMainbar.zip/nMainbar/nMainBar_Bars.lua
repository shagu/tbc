if (SHORT_BAR == false) then return end 

    --========[ possessbar anchor ]========--

local nMainbar_Possess = CreateFrame("Frame", "PossAnc", UIParent)
nMainbar_Possess:SetBackdrop({bgFile = "Interface/QuestFrame/UI-Quest-BulletPoint"})
nMainbar_Possess:SetFrameStrata("BACKGROUND")
nMainbar_Possess:SetBackdropColor(0.8, 0, 0)
nMainbar_Possess:SetWidth(22)
nMainbar_Possess:SetHeight(22)
nMainbar_Possess:SetPoint("CENTER", UIParent, 0, 30)
nMainbar_Possess:EnableMouse(true)
nMainbar_Possess:SetMovable(true)
nMainbar_Possess:SetUserPlaced(true)
nMainbar_Possess:Hide()

nMainbar_Possess:SetScript("OnMouseDown", function() 
    if (IsShiftKeyDown()) then
        PossAnc:Hide()
    else
        nMainbar_Possess:ClearAllPoints() 
        nMainbar_Possess:StartMoving() 
    end
end)

nMainbar_Possess:SetScript("OnMouseUp", function() 
    nMainbar_Possess:StopMovingOrSizing() 
end)

nMainbar_Possess:SetScript("OnEnter", function () 
    GameTooltip:SetOwner(nMainbar_Possess, "ANCHOR_LEFT") 
    GameTooltip:AddLine("姿态条")
    GameTooltip:AddLine("左键拖动")
    GameTooltip:AddLine("Shift+点击 隐藏")
    GameTooltip:Show()
end)

nMainbar_Possess:SetScript("OnLeave", function () 
    GameTooltip:Hide() 
end)

UIPARENT_MANAGED_FRAME_POSITIONS["ShapeshiftBarFrame"] = nil
PossessBarFrame:ClearAllPoints()
PossessButton1:ClearAllPoints()
PossessButton1:SetPoint("TOPLEFT", nMainbar_Possess, "BOTTOMRIGHT")
    
    --========[ stancebar anchor ]========--

local nMainbar_Shape = CreateFrame("Frame", "ShapeAnc", UIParent)
nMainbar_Shape:SetBackdrop({bgFile = "Interface/QuestFrame/UI-Quest-BulletPoint"})
nMainbar_Shape:SetFrameStrata("BACKGROUND")
nMainbar_Shape:SetBackdropColor(0, 0.75, 0)
nMainbar_Shape:SetWidth(22)
nMainbar_Shape:SetHeight(22)
nMainbar_Shape:SetPoint("CENTER", UIParent, 0, -30)
nMainbar_Shape:EnableMouse(true)
nMainbar_Shape:SetMovable(true)
nMainbar_Shape:SetUserPlaced(true)
nMainbar_Shape:Hide()

nMainbar_Shape:SetScript("OnMouseDown", function() 
    if (IsShiftKeyDown()) then
        ShapeAnc:Hide()
    else
        nMainbar_Shape:ClearAllPoints()
        nMainbar_Shape:StartMoving()
    end
end)

nMainbar_Shape:SetScript("OnMouseUp", function() 
    nMainbar_Shape:StopMovingOrSizing() 
end)

nMainbar_Shape:SetScript("OnEnter", function () 
    GameTooltip:SetOwner(nMainbar_Shape, "ANCHOR_LEFT") 
    GameTooltip:AddLine("变身/控制条")
    GameTooltip:AddLine("左键拖动")
    GameTooltip:AddLine("Shift+点击 隐藏")
    GameTooltip:Show()
end)

nMainbar_Shape:SetScript("OnLeave", function() 
    GameTooltip:Hide() 
end)

UIPARENT_MANAGED_FRAME_POSITIONS["ShapeshiftBarFrame"] = nil
ShapeshiftBarFrame:ClearAllPoints()
ShapeshiftButton1:ClearAllPoints()
ShapeshiftButton1:SetPoint("TOPLEFT", nMainbar_Shape, "BOTTOMRIGHT")
    
    --========[ petbar anchor ]========--

local nMainbar_Pet = CreateFrame("Frame", "PetAnc", UIParent)
nMainbar_Pet:SetBackdrop({bgFile = "Interface/QuestFrame/UI-Quest-BulletPoint"})
nMainbar_Pet:SetFrameStrata("BACKGROUND")
nMainbar_Pet:SetWidth(22)
nMainbar_Pet:SetHeight(22)
nMainbar_Pet:SetBackdropColor(1, 1, 1)
nMainbar_Pet:SetPoint("CENTER", UIParent)
nMainbar_Pet:EnableMouse(true)
nMainbar_Pet:SetMovable(true)
nMainbar_Pet:SetUserPlaced(true)
nMainbar_Pet:Hide()

nMainbar_Pet:SetScript("OnMouseDown", function() 
    if (IsShiftKeyDown()) then
        PetAnc:Hide()
    else
        nMainbar_Pet:ClearAllPoints()
        nMainbar_Pet:StartMoving()
    end
end)

nMainbar_Pet:SetScript("OnMouseUp", function() 
    nMainbar_Pet:StopMovingOrSizing() 
end)

nMainbar_Pet:SetScript("OnEnter", function() 
    GameTooltip:SetOwner(nMainbar_Pet, "ANCHOR_LEFT") 
    GameTooltip:AddLine("宠物条")
    GameTooltip:AddLine("左键拖动")
    GameTooltip:AddLine("Shift+点击 隐藏")
    GameTooltip:Show()
end)

nMainbar_Pet:SetScript("OnLeave", function() 
    GameTooltip:Hide() 
end)

UIPARENT_MANAGED_FRAME_POSITIONS["PetActionBarFrame"] = nil
PetActionBarFrame:ClearAllPoints()
PetActionButton1:ClearAllPoints()
PetActionButton1:SetPoint("TOPLEFT", nMainbar_Pet, "BOTTOMRIGHT")

    --========[ bottom right bar ]========--

MoveBottomRight = function(attach, x, y)
    UIPARENT_MANAGED_FRAME_POSITIONS["MultiBarRight"] = nil
    MultiBarBottomRight:ClearAllPoints()
    MultiBarBottomRight:SetPoint("BOTTOM", attach, "TOP", x, y)
end

nMainbar_MoveTehDamnBars = function(...)
    if (UnitLevel("player") == MAX_PLAYER_LEVEL and not ReputationWatchBar:IsShown()) then
        if (MultiBarBottomLeft:IsShown() and MultiBarBottomLeft:IsShown()) then
            MoveBottomRight(MultiBarBottomLeft, 0, 4)
        elseif (MultiBarBottomRight:IsShown() and not MultiBarBottomLeft:IsShown()) then
            MoveBottomRight(MainMenuBar, 2, -1)
        end
    elseif (UnitLevel("player") == MAX_PLAYER_LEVEL and ReputationWatchBar:IsShown()) then
        if (MultiBarBottomLeft:IsShown() and MultiBarBottomLeft:IsShown()) then
            MoveBottomRight(MultiBarBottomLeft, 0, 4)
        elseif (MultiBarBottomRight:IsShown() and not MultiBarBottomLeft:IsShown()) then
            MoveBottomRight(MainMenuBar, 2, 4)
        end
    elseif (MainMenuExpBar:IsShown() and not ReputationWatchBar:IsShown()) then
        if (MultiBarBottomLeft:IsShown() and MultiBarBottomLeft:IsShown()) then
            MoveBottomRight(MultiBarBottomLeft, 0, 4)
        elseif (MultiBarBottomRight:IsShown() and not MultiBarBottomLeft:IsShown()) then
            MoveBottomRight(MainMenuBar, 2, 4)
        end
    elseif (MainMenuExpBar:IsShown() and ReputationWatchBar:IsShown()) then
        if (MultiBarBottomLeft:IsShown() and MultiBarBottomLeft:IsShown()) then
            MoveBottomRight(MultiBarBottomLeft, 0, 4)
        elseif (MultiBarBottomRight:IsShown() and not MultiBarBottomLeft:IsShown()) then
            MoveBottomRight(MainMenuBar, 2, 13)
        end
    end	
end
hooksecurefunc("UIParent_ManageFramePosition", nMainbar_MoveTehDamnBars)

    --========[ slash config ]========--
    
local function nMainbar_SlashConfig(msg)
    if string.lower(msg) == "toggle" then
        if (PossAnc:IsShown() or ShapeAnc:IsShown() or PetAnc:IsShown()) then
            PossAnc:Hide()
            ShapeAnc:Hide()
            PetAnc:Hide()
            DEFAULT_CHAT_FRAME:AddMessage("|cff01DFD7n|rMainBar - |cff01DFD7所有动作条现在处于 隐藏状态")
        else
            PossAnc:Show()
            ShapeAnc:Show()
            PetAnc:Show()
            DEFAULT_CHAT_FRAME:AddMessage("|cff01DFD7n|rMainBar - |cff01DFD7所有动作条现在处于 显示状态")
        end
    elseif string.lower(msg) == "reset" then
        PetAnc:SetPoint("CENTER", UIParent)
        ShapeAnc:SetPoint("CENTER", UIParent, 0, -30)
        PossAnc:SetPoint("CENTER", UIParent, 0, 30)
        DEFAULT_CHAT_FRAME:AddMessage("|cff01DFD7n|rMainBar - |cff01DFD7所有位置恢复默认")
	elseif string.lower(msg) == "" then
        DEFAULT_CHAT_FRAME:AddMessage("|cff01DFD7n|rMainBar: ")
		DEFAULT_CHAT_FRAME:AddMessage("/nmb toggle - |cff01DFD7显示动作条,姿态条等 ")
        DEFAULT_CHAT_FRAME:AddMessage("/nmb reset - |cff01DFD7重置所有定位")
	else
        DEFAULT_CHAT_FRAME:AddMessage("|cff01DFD7n|rMainBar: ")
		DEFAULT_CHAT_FRAME:AddMessage("/nmb toggle - |cff01DFD7显示动作条,姿态条等 ")
        DEFAULT_CHAT_FRAME:AddMessage("/nmb reset - |cff01DFD7重置所有位置")
	end
end

_G["SlashCmdList"]["nMainbar_SlashConfig"] = nMainbar_SlashConfig
_G["SLASH_nMainbar_SlashConfig1"] = "/nmb"
_G["SLASH_nMainbar_SlashConfig2"] = "/nMainbar"