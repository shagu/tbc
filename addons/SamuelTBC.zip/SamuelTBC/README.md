# SamuelTBC
Simple and light Swing timer addon for TBC

It produces a 5px high and 200px wide black bar with a white progress bar filling up till the next expected swing/shot.
Works for 2h Weapons, bows and wands.
You can add a red marker to indicate deadzone or to assist in timing movement to prevent clipping using the slashcommands.
The size of the red marker can be adjusted.

### Installation:
Create a folder named `SamuelTBC` in your `Interface/AddOns/` folder and put the files `SamuelTBC.toc` and `SamuelTBC.lua` in that folder.

or

Just clone the repo straight into your `Interface/AddOns/` folder.

### Slashcommands:
* `/sam`
* `/samuel`

The Addon will explain the rest from there.
