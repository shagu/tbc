local Shadikith = DBM:NewBossMod("Shadikith", DBM_SHAD_NAME, nil, DBM_KARAZHAN);
Shadikith:RegisterCombat("COMBAT");

local Hyakiss = DBM:NewBossMod("Hyakiss", DBM_HYA_NAME, nil, DBM_KARAZHAN);
Hyakiss:RegisterCombat("COMBAT");

local Rokad = DBM:NewBossMod("Rokad", DBM_ROKAD_NAME, nil, DBM_KARAZHAN);
Rokad:RegisterCombat("COMBAT");