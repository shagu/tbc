if not SimpleUnitFrames or not SimpleUnitFrames:HasModule("PortraitDamage") then return end

local core = SimpleUnitFrames
local PortraitDamage = core:GetModule("PortraitDamage")

for i=1, 4 do
	local parent = "PartyMemberFrame"..i
	PortraitDamage.frameSettings["party"..i] = {
		parent = _G[parent],
		font = "NumberFontNormalHuge",
		point = { "CENTER", _G[parent.."Portrait"], "CENTER" },
		size = 30,
	}
	
	parent = "PartyMemberFrame"..i.."PetFrame"
	PortraitDamage.frameSettings["partypet"..i] = {
		parent = _G[parent],
		font = "NumberFontNormalLarge",
		point = { "CENTER", _G[parent.."Portrait"], "CENTER" },
		size = 16,
	}
end