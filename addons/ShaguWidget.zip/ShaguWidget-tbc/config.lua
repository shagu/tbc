ShaguWidget.defconfig = {
  ["Default"] = [[{color 33ffcc}{size 12}{date %A}
{color ffffff}{size 27}{font NovaFlat}{date %H:%M:%S}
{color 33ffcc}{size 10}{date %Y-%m-%d}
{color}
server: {color ffffff}{serverh}:{serverm}
realm: {color ffffff}{realm}
gold: {color ffffff}{gold}{color}g {color ffffff}{silver}{color cccccc}s {color ffffff}{copper}{color aa8855}c
{color}
upload: {color ffffff}{up}kb/s
download: {color ffffff}{down}kb/s
mem: {color ffffff}{mem} MB
ping: {color ffffff}{ping}ms
fps: {color ffffff}{fps}
]],
}
