--[[----------------------------------------------------------------------------
	Copyright 2008 João Liborio Cardoso
	All rights reserved
	
	Scrap Options is part of Scrap
	Scrap Options is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License version 3 as published by the Free Software Foundation.
	Scrap Options is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License (<http://www.gnu.org/licenses/>) for more details.
---------------------------------------------------------------------------]]--

local L = Scrap.Locals
local _G = getfenv()

function Scrap:CreateDropdown()

	self.Dropdown = CreateFrame("Frame", "ScrapDropdown", self, "UIDropDownMenuTemplate")
	self.Dropdown:SetClampedToScreen(true)
	
	UIDropDownMenu_Initialize(self.Dropdown, function(...) self:BuildDropdown(...) end, "MENU")
	StaticPopupDialogs["Scrap_CreateProfile"] = self:CreateProfilePopup()
	
end

function Scrap:ForEachProfile(func)
	local match
	for name,value in pairs(Scrap_SV.profiles) do
		if name ~= self:GetCurrentProfile() then
			match = nil
		else
			match = true
		end
		func(name,value,match)
	end
end

function Scrap:CopyProfile(new, old)
	for k,v in pairs(new) do
		new[k] = nil
	end
	for k,v in pairs(old) do
		if v ~= 'table' then
			new[k] = v
		else
			new[k] = {}
			self:CopyProfile(new[k], v)
		end
	end
end


--[[ Popup Dialogs ]]--

function Scrap:CreateProfilePopup()
	local popup = {
		text = L.EnterName,
		button1 = ACCEPT,
		button2 = CANCEL,
		hasEditBox = 1,
		maxLetters = 24,
		OnAccept = function()
			local text = _G[this:GetParent():GetName().."EditBox"]:GetText()
			if text ~= "" and text ~= self:GetCurrentProfile() then
				local oldProfile = self.sets
				self:SetProfile(text)
				self:CopyProfile(self.sets, oldProfile)
				self:Print(L.ProfileCreated, text)
			else
				self:Print(L.InvalidProfile)
			end
		end,
		OnShow = function()
			local EditBox = _G[this:GetName().."EditBox"]
			EditBox:SetFocus()
			EditBox:SetText(UnitName("player"))
			EditBox:HighlightText()
		end,
		OnHide = function()
			if ChatFrameEditBox:IsVisible() then
				ChatFrameEditBox:SetFocus()
			end
			_G[this:GetName().."EditBox"]:SetText("")
		end,
		timeout = 0, exclusive = 1, hideOnEscape = 1
	}
	
	popup.EditBoxOnEnterPressed = popup.OnAccept
	return popup
end

function Scrap:DeleteProfilePopup(name)
	return {
		text = format(L.DeleteProfilePopup, name),
		button1 = OKAY,
		button2 = CANCEL,
		OnAccept = function()
			Scrap_SV.profiles[name] = nil
			Scrap:Print(L.ProfileDeleted, name)
		end,
		timeout = 0,
		hideOnEscape = 1
	}
end


--[[ Create the Dropdown ]]--

function Scrap:BuildDropdown(level)

	if not level or level == 1 then
	
		UIDropDownMenu_AddButton({
			text = L.AutoSell,
			func = function() self.sets.autoSell = not self.sets.autoSell end,
			checked = self.sets.autoSell
		})
		UIDropDownMenu_AddButton({
			text = L.ShowHelp,
			func = function() self.sets.help = not self.sets.help end,
			checked = self.sets.help
		})
		
		UIDropDownMenu_AddButton({
			text = L.Profiles,
			notClickable = 1,
			isTitle = 1
		})
		UIDropDownMenu_AddButton({
			text = L.CreateProfile,
			func = function() StaticPopup_Show("Scrap_CreateProfile") end
		})
		UIDropDownMenu_AddButton({
			text = L.SetProfile,
			hasArrow = true,
			value = "Set",
		})
		UIDropDownMenu_AddButton({
			text = L.DeleteProfile,
			hasArrow = true,
			value = "Delete",
		})
		
	elseif UIDROPDOWNMENU_MENU_VALUE == "Set" then
		self:ForEachProfile(function(name, value, match)
			UIDropDownMenu_AddButton({
				text = name,
				checked = match,
				notClickable = match,
				func = function() 
					self:SetProfile(name)
					self:Print(L.ProfileChanged, name)

					self:OnClick() self:OnClick() --trick to update dropdown
					self:UpdateButtonState()
					self:UpdateModules()
				end,
			}, 2)
		end)
		
	elseif UIDROPDOWNMENU_MENU_VALUE == "Delete" then
		self:ForEachProfile(function(name, value, disabled)
			if disabled then
				name = "|cff808080"..name
			end
			UIDropDownMenu_AddButton({
				text = name,
				notClickable = disabled,
				func = function() 
					StaticPopupDialogs["Scrap_DeleteProfile"] = self:DeleteProfilePopup(name)
					StaticPopup_Show("Scrap_DeleteProfile")
				end,
			}, 2)
		end)
	end
end

--[[ Call Addon ]]--

Scrap:CreateDropdown()