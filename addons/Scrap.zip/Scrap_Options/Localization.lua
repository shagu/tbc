Scrap.Locals = {}
local L = Scrap.Locals

--english
L.AutoSell = "Auto Sell Junk"
L.ShowHelp = "Show Help Tooltip"
L.Profiles = "Profiles"
L.CreateProfile = "Create Profile"
L.EnterName = "Enter a name for the new profile:"
L.ProfileCreated = "Created profile %q"
L.InvalidProfile = "Invalid profile name"
L.SetProfile = "Set Profile"
L.ProfileChanged = "Set profile to %q"
L.DeleteProfile = "Delete Profile"
L.DeleteProfilePopup = "Are you sure you want to delete the profile %q?"
L.ProfileDeleted = "Deleted profile %q"