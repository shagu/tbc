Scrap.Locals = {}
local L = Scrap.Locals

--english
L.Info = "<Left Click> to sell all junk\n<Right Click> to toggle options\n<Drag Item> to remove/add it to junk list"
L.SellJunk = "Sell Junk"
L.Add = "Add To Junk List"
L.Remove = "Remove From Junk List"
L.Added = "%s was added to junk list."
L.Removed = "%s was removed from junk list."
L.OptionsDisabled = "missing Scrap Options addon."
L.Default = "Default"