﻿local L = LibStub("AceLocale-3.0"):NewLocale("MageAnnounce", "koKR")
if not L then return end
     
	----- Options Names -----
	L["Options"] = "설정"
	L["General"] = "일반"
	L["General Options"] = "일반 설정"
	L["Enable in BGs"] = "전장에서 사용"
	L["Enable Outside Instances"] = "인던 밖에서 사용"
	L["Custom Channel"] = "전역 채널"
	--
	L["Message"] = "메세지"
	L["Show in Raid"] = "공격대창에 표시"
	L["Show in Party"] = "파티창에 표시"
	L["Show in Custom Channel"] = "전역 채널에 표시"
	-- Polymorph Options
	L["Polymorph Options"] = "변이 설정"
	L["I use a focus macro"] = "주시 매크로 사용"
	L["Enable Warning Messages"] = "경보 메세지 사용"
	L["Warning Message"] = "경보 메세지"
	-- Other Spell Options
	L["Counterspell Options"] = "마법 차단 설정"
	L["Slow Options"] = "감속 설정"
	L["Portal Options"] = "차원의 문 설정"

	----- Options Descriptions -----
	L["Shows the Options Menu"] = "설정 메뉴 표시"
	L["Enable messages in Battlegrounds"] = "전장에서 메세지 사용"
	L["Enable messages outside Instances"] = "인던밖에서 메세지 사용"
	L["Custom channel to show messages in"] = "전역 채널에서 메세지 보이기"
	-- Polymorph Options
	L["Show Polymorph Options"] = "변이 설정 표시"
	L["Check this if you use a focus macro for sheeping"] = "주시 변이 메크로 사용하는지 확인"
	L["Message to be displayed when polymorphing"] = "변이를 사용할때 표시될 메세지"
	L["Message to be displayed when counterspelling"] = "마법 차단을 사용할때 표시될 메세지"
	L["Message to be displayed when slowing"] = "감속을 사용할때 표시될 메세지"
	L["Toggles the display of polymorph messages in raid chat"] = "공격대 창에 변이 메세지를 표시합니다."
	L["Toggles the display of polymorph messages in party chat"] = "파티 창에 변이 메세지를 표시합니다."
	L["Toggles the display of polymorph messages in the custom channel"] = "전역 채널에 변이 메세지를 표시합니다."
	L["Toggles the sending of polymorph warning via whisper"] = "귓속말로 변이 경고를 보냅니다."
	L["Message to be sent to party members who target your target when polymorphing"] = "변이 타켓을 하고 있는 파티원에게 메세지를 보냅니다."
	-- Counterspell Options
	L["Show Counterspell Options"] = "마법 차단 설정 표시"
	L["Toggles the display of counterspell messages in raid chat"] = "공격대 창에 마법 차단 메세지를 표시합니다."
	L["Toggles the display of counterspell messages in party chat"] = "파티창에 마법 차단 메세지를 표시합니다."
	L["Toggles the display of counterspell messages in the custom channel"] = "전역 채널에 마법 차단 메세지를 표시합니다."
	-- Slow Options
	L["Show Slow Options"] = "감속 설정 표시"
	L["Toggles the display of slow messages in raid chat"] = "공격대 창에 감속 메세지를 표시합니다."
	L["Toggles the display of slow messages in party chat"] = "파티 창에 감속 메세지를 표시합니다."
	L["Toggles the display of slow messages in the custom channel"] = "전역 채널에 감속 메세지를 표시합니다."
	-- Portal Options
	L["Show Portal Options"] = "차원의 문 설정 표시"
	L["Toggles the display of portal messages in raid chat"] = "공격대 창에 차원의 문 메세지를 표시합니다."
	L["Toggles the display of portal messages in party chat"] = "파티창에 차원의 문 메세지를 표시합니다."
	L["Toggles the display of portal messages in the custom channel"] = "전역 채널에 차원의 문 메세지를 표시합니다."
	L["Message to be displayed when opening a portal, %s will be replace with the city name"] = "차원의 문을 열때 %s는 도시의 이름으로 표시됩니다."
	----- Default Messages -----
	L["Now Polymorphing %t"] = "%t 변이 합니다."
	L["Counterspelling %t"] = "%t 마법 차단 했습니다."
	L["Slowing %t"] = "%t 감속 걸렸습니다."
	L["Incoming Portal to %s"] = "%s 포탈 엽니다."
	L["I am casting Polymorph on your target. Please stop attacking!"] = "지금 당신의 타켓대상을 양변합니다. 공격 중지 해주세요!"

	----- Usage Descriptions -----
	L["<Your message>"] = "<당신의 메세지>"
	L["<Channel>"] = "<채널>"

	----- Spell Strings -----
	L["Portal"] = "차원의 문"
	L["Polymorph"] = "변이"
	L["Counterspell"] = "마법 차단"
	L["Slow"] = "감속"