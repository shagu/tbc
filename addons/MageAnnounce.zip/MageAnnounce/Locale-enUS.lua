local L = LibStub("AceLocale-3.0"):NewLocale("MageAnnounce", "enUS", true)
if not L then return end
     
	----- Options Names -----
	L["Options"] = true
	L["General"] = true
	L["General Options"] = true
	L["Enable in BGs"] = true
	L["Enable Outside Instances"] = true
	L["Custom Channel"] = true
	--
	L["Message"] = true
	L["Show in Raid"] = true
	L["Show in Party"] = true
	L["Show in Custom Channel"] = true
	-- Polymorph Options
	L["Polymorph Options"] = true
	L["I use a focus macro"] = true
	L["Enable Warning Messages"] = true
	L["Warning Message"] = true
	-- Other Spell Options
	L["Counterspell Options"] = true
	L["Slow Options"] = true
	L["Portal Options"] = true

	----- Options Descriptions -----
	L["Shows the Options Menu"] = true
	L["Enable messages in Battlegrounds"] = true
	L["Enable messages outside Instances"] = true
	L["Custom channel to show messages in"] = true
	-- Polymorph Options
	L["Show Polymorph Options"] = true
	L["Check this if you use a focus macro for sheeping"] = true
	L["Message to be displayed when polymorphing"] = true
	L["Message to be displayed when counterspelling"] = true
	L["Message to be displayed when slowing"] = true
	L["Toggles the display of polymorph messages in raid chat"] = true
	L["Toggles the display of polymorph messages in party chat"] = true
	L["Toggles the display of polymorph messages in the custom channel"] = true
	L["Toggles the sending of polymorph warning via whisper"] = true
	L["Message to be sent to party members who target your target when polymorphing"] = true
	-- Counterspell Options
	L["Show Counterspell Options"] = true
	L["Toggles the display of counterspell messages in raid chat"] = true
	L["Toggles the display of counterspell messages in party chat"] = true
	L["Toggles the display of counterspell messages in the custom channel"] = true
	-- Slow Options
	L["Show Slow Options"] = true
	L["Toggles the display of slow messages in raid chat"] = true
	L["Toggles the display of slow messages in party chat"] = true
	L["Toggles the display of slow messages in the custom channel"] = true
	-- Portal Options
	L["Show Portal Options"] = true
	L["Toggles the display of portal messages in raid chat"] = true
	L["Toggles the display of portal messages in party chat"] = true
	L["Toggles the display of portal messages in the custom channel"] = true
	L["Message to be displayed when opening a portal, %s will be replace with the city name"] = true
	----- Default Messages -----
	L["Now Polymorphing %t"] = true
	L["Counterspelling %t"] = true
	L["Slowing %t"] = true
	L["Incoming Portal to %s"] = true
	L["I am casting Polymorph on your target. Please stop attacking!"] = true

	----- Usage Descriptions -----
	L["<Your message>"] = true
	L["<Channel>"] = true

	----- Spell Strings -----
	L["Portal"] = true
	L["Polymorph"] = true
	L["Counterspell"] = true
	L["Slow"] = true