local L = LibStub("AceLocale-3.0"):NewLocale("MageAnnounce", "zhTW", true)
if not L then return end
     
	----- Options Names -----
	L["Options"] = "設定"
	L["General"] = "一般"
	L["General Options"] = "一般設定"
	L["Enable in BGs"] = "在戰場啟用"
	L["Enable Outside Instances"] = "在副本之外啟用"
	L["Custom Channel"] = "預設頻道"
	--
	L["Message"] = "訊息"
	L["Show in Raid"] = "在團隊中顯示訊息"
	L["Show in Party"] =  "在隊伍中顯示訊息"
	L["Show in Custom Channel"] =  "在預設頻道顯示訊息"
	-- Polymorph Options
	L["Polymorph Options"] = "變形術設定"
	L["I use a focus macro"] = "我使用一個監控巨集"
	L["Enable Warning Messages"] = "啟用警告提示"
	L["Warning Message"] = "警告提示"
	-- Other Spell Options
	L["Counterspell Options"] = "法術反制設定"
	L["Slow Options"] = "減速術設定"
	L["Portal Options"] = "傳送門設定"

	----- Options Descriptions -----
	L["Shows the Options Menu"] = "顯示設定選單"
	L["Enable messages in Battlegrounds"] = "在戰場中啟用訊息"
	L["Enable messages outside Instances"] = "在副本之外啟用訊息"
	L["Custom channel to show messages in"] = "Custom channel to show messages in"
	-- Polymorph Options
	L["Show Polymorph Options"] = "顯示變形術設定"
	L["Check this if you use a focus macro for sheeping"] = "Check this if you use a focus macro for sheeping"
	L["Message to be displayed when polymorphing"] = "Message to be displayed when polymorphing"
	L["Message to be displayed when counterspelling"] = "Message to be displayed when counterspelling"
	L["Message to be displayed when slowing"] = "Message to be displayed when slowing"
	L["Toggles the display of polymorph messages in raid chat"] = "Toggles the display of polymorph messages in raid chat"
	L["Toggles the display of polymorph messages in party chat"] = "Toggles the display of polymorph messages in party chat"
	L["Toggles the display of polymorph messages in the custom channel"] = "Toggles the display of polymorph messages in the custom channel"
	L["Toggles the sending of polymorph warning via whisper"] = "Toggles the sending of polymorph warning via whisper"
	L["Message to be sent to party members who target your target when polymorphing"] = "Message to be sent to party members who target your target when polymorphing"
	-- Counterspell Options
	L["Show Counterspell Options"] = "顯示法術反制設定"
	L["Toggles the display of counterspell messages in raid chat"] = "Toggles the display of counterspell messages in raid chat"
	L["Toggles the display of counterspell messages in party chat"] = "Toggles the display of counterspell messages in party chat"
	L["Toggles the display of counterspell messages in the custom channel"] = "Toggles the display of counterspell messages in the custom channel"
	-- Slow Options
	L["Show Slow Options"] = "顯示減速術設定"
	L["Toggles the display of slow messages in raid chat"] = "Toggles the display of slow messages in raid chat"
	L["Toggles the display of slow messages in party chat"] = "Toggles the display of slow messages in party chat"
	L["Toggles the display of slow messages in the custom channel"] = "Toggles the display of slow messages in the custom channel"
	-- Portal Options
	L["Show Portal Options"] = "顯示傳送門設定"
	L["Toggles the display of portal messages in raid chat"] = "Toggles the display of portal messages in raid chat"
	L["Toggles the display of portal messages in party chat"] = "Toggles the display of portal messages in party chat"
	L["Toggles the display of portal messages in the custom channel"] = "Toggles the display of portal messages in the custom channel"
	L["Message to be displayed when opening a portal, %s will be replace with the city name"] = "Message to be displayed when opening a portal, %s will be replace with the city name"
	----- Default Messages -----
	L["Now Polymorphing %t"] = "對 %t 施放 變形術"
	L["Counterspelling %t"] = "對 %t 施放 法術反制"
	L["Slowing %t"] = "對 %T 施放 減速術"
	L["Incoming Portal to %s"] = "Incoming Portal to %s"
	L["I am casting Polymorph on your target. Please stop attacking!"] = "我正對你的目標施放變形術.請停止攻擊!"

	----- Usage Descriptions -----
	L["<Your message>"] = "<Your message>"
	L["<Channel>"] = "<Channel>"

	----- Spell Strings -----
	L["Portal"] = "傳送門"
	L["Polymorph"] = "變形術"
	L["Counterspell"] = "法術反制"
	L["Slow"] = "減速術"