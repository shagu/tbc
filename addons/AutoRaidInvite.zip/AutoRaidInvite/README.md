# AutoRaidInvite
WoW 2.4.3 Addon <br>
Invites guildies into grp/raid if they whisper "inv", "invite", "raid" or "+" <br>
Automatically converts to raid if 5 people in grp and another whisper comes <br>
Planned features: Customizable magic words, on/off switch
