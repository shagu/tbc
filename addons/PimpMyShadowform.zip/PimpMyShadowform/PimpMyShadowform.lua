﻿if select(2, UnitClass("player")) ~= "PRIEST" then
	return
end

local ShadowFrame = CreateFrame("Frame", "ShadowFrame", UIParent)
ShadowFrame:SetPoint("CENTER")
ShadowFrame:SetWidth(175)
ShadowFrame:SetHeight(90)

local ShadowFrameBackground = ShadowFrame:CreateTexture(nil, "BACKGROUND")
ShadowFrameBackground:SetAllPoints()
ShadowFrameBackground:SetTexture(0, 0, 0, 0.4)
ShadowFrameBackground:SetWidth(130)
ShadowFrameBackground:SetHeight(90)

ShadowFrame:SetMovable(true)
ShadowFrame:EnableMouse(true)
ShadowFrame:RegisterForDrag("LeftButton")
ShadowFrame:SetScript("OnDragStart", function() ShadowFrame:StartMoving() end)
ShadowFrame:SetScript("OnDragStop", function() ShadowFrame:StopMovingOrSizing() end)

local MindBlastFrame = CreateFrame("Frame", nil, UIParent)
MindBlastFrame:SetPoint("TOPLEFT", ShadowFrame, 0, 0)
MindBlastFrame:SetWidth(45)
MindBlastFrame:SetHeight(45)
local MindBlastTexture = MindBlastFrame:CreateTexture(nil)
MindBlastTexture:SetTexture("Interface\\Icons\\Spell_Shadow_UnholyFrenzy")
MindBlastTexture:SetTexCoord(0.06, 0.94, 0.06, 0.94)
MindBlastTexture:SetAllPoints()
local MindBlastCooldown = CreateFrame("Cooldown", "MindBlastCooldown", MindBlastFrame, "CooldownFrameTemplate")
MindBlastCooldown:SetAllPoints()
local MindBlastCooldownFrame = CreateFrame("Frame")
MindBlastCooldownFrame:SetFrameLevel(4)
local MindBlastCooldownFont = MindBlastCooldownFrame:CreateFontString(MindBlastCooldownFont, "ARTWORK", "GameFontNormal")
MindBlastCooldownFont:SetPoint("CENTER", MindBlastFrame)
MindBlastCooldownFont:SetFont("Fonts\\FRIZQT__.TTF", 16, "THICKOUTLINE")
MindBlastCooldownFont:SetTextColor(1, 0, 0)
MindBlastCooldownFont:SetText("")

local SWDFrame = CreateFrame("Frame", nil, UIParent)
SWDFrame:SetPoint("TOPLEFT", ShadowFrame, 0, -45)
SWDFrame:SetWidth(45)
SWDFrame:SetHeight(45)
local SWDTexture = SWDFrame:CreateTexture(nil)
SWDTexture:SetTexture("Interface\\Icons\\Spell_Shadow_DemonicFortitude")
SWDTexture:SetTexCoord(0.06, 0.94, 0.06, 0.94)
SWDTexture:SetAllPoints()
local SWDCooldown = CreateFrame("Cooldown", "SWDCooldown", SWDFrame, "CooldownFrameTemplate")
SWDCooldown:SetAllPoints()
local SWDCooldownFrame = CreateFrame("Frame")
SWDCooldownFrame:SetFrameLevel(4)
local SWDCooldownFont = SWDCooldownFrame:CreateFontString(SWDCooldownFont, "ARTWORK", "GameFontNormal")
SWDCooldownFont:SetPoint("CENTER", SWDFrame)
SWDCooldownFont:SetFont("Fonts\\FRIZQT__.TTF", 16, "THICKOUTLINE")
SWDCooldownFont:SetTextColor(1, 0, 0)
SWDCooldownFont:SetText("")

local VampiricTouchTexture = ShadowFrame:CreateTexture(nil)
VampiricTouchTexture:SetTexture("Interface\\Icons\\Spell_Holy_Stoicism")
VampiricTouchTexture:SetPoint("TOPLEFT", ShadowFrame, 45, 0)
VampiricTouchTexture:SetWidth(30)
VampiricTouchTexture:SetHeight(30)
VampiricTouchTexture:SetTexCoord(0.06, 0.94, 0.06, 0.94)

local VampiricTouchStatusBar = CreateFrame("StatusBar", "VampiricTouchStatusBar", ShadowFrame)
VampiricTouchStatusBar:SetPoint("TOPLEFT", 75, 0)
VampiricTouchStatusBar:SetStatusBarTexture("Interface\\AddOns\\PimpMyShadowform\\statusbar")
VampiricTouchStatusBar:SetOrientation("HORIZONTAL")
VampiricTouchStatusBar:SetWidth(100)
VampiricTouchStatusBar:SetHeight(30)
VampiricTouchStatusBar:SetMinMaxValues(0, 1)
VampiricTouchStatusBar:SetValue(1)
VampiricTouchStatusBar:SetStatusBarColor(0.54, 0.18, 0.89)
VampiricTouchStatusBar:SetFrameLevel("1")
VampiricTouchStatusBar:SetValue(0)

local SWPTexture = ShadowFrame:CreateTexture(nil)
SWPTexture:SetTexture("Interface\\Icons\\Spell_Shadow_ShadowWordPain")
SWPTexture:SetPoint("TOPLEFT", ShadowFrame, 45, -30)
SWPTexture:SetWidth(30)
SWPTexture:SetHeight(30)
SWPTexture:SetTexCoord(0.06, 0.94, 0.06, 0.94)

local SWPStatusBar = CreateFrame("StatusBar", "SWPStatusBar", ShadowFrame)
SWPStatusBar:SetPoint("TOPLEFT", 75, -30)
SWPStatusBar:SetStatusBarTexture("Interface\\AddOns\\PimpMyShadowform\\statusbar")
SWPStatusBar:SetOrientation("HORIZONTAL")
SWPStatusBar:SetWidth(100)
SWPStatusBar:SetHeight(30)
SWPStatusBar:SetMinMaxValues(0, 1)
SWPStatusBar:SetValue(1)
SWPStatusBar:SetStatusBarColor(1, 0.55, 0)
SWPStatusBar:SetFrameLevel("1")
SWPStatusBar:SetValue(0)

local MindFlayTexture = ShadowFrame:CreateTexture(nil)
MindFlayTexture:SetTexture("Interface\\Icons\\Spell_Shadow_SiphonMana")
MindFlayTexture:SetPoint("TOPLEFT", ShadowFrame, 45, -60)
MindFlayTexture:SetWidth(30)
MindFlayTexture:SetHeight(30)
MindFlayTexture:SetTexCoord(0.06, 0.94, 0.06, 0.94)

local MindFlayStatusBar = CreateFrame("StatusBar", "MindFlayStatusBar", ShadowFrame)
MindFlayStatusBar:SetPoint("TOPLEFT", 75, -60)
MindFlayStatusBar:SetStatusBarTexture("Interface\\AddOns\\PimpMyShadowform\\statusbar")
MindFlayStatusBar:SetOrientation("HORIZONTAL")
MindFlayStatusBar:SetWidth(100)
MindFlayStatusBar:SetHeight(30)
MindFlayStatusBar:SetMinMaxValues(0, 1)
MindFlayStatusBar:SetValue(1)
MindFlayStatusBar:SetStatusBarColor(0, 0.5, 1)
MindFlayStatusBar:SetFrameLevel("1")
MindFlayStatusBar:SetValue(0)

local MindFlaySparkling1 = MindFlayStatusBar:CreateTexture(nil, "OVERLAY")
MindFlaySparkling1:SetPoint("LEFT", -5, 0)
MindFlaySparkling1:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
MindFlaySparkling1:SetWidth(10)
MindFlaySparkling1:SetHeight(40)
MindFlaySparkling1:SetBlendMode("ADD")
MindFlaySparkling1:Hide()

local MindFlaySparkling2 = MindFlayStatusBar:CreateTexture(nil, "OVERLAY")
MindFlaySparkling2:SetPoint("LEFT", 28, 0)
MindFlaySparkling2:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
MindFlaySparkling2:SetWidth(10)
MindFlaySparkling2:SetHeight(40)
MindFlaySparkling2:SetBlendMode("ADD")
MindFlaySparkling2:Hide()

local MindFlaySparkling3 = MindFlayStatusBar:CreateTexture(nil, "OVERLAY")
MindFlaySparkling3:SetPoint("LEFT", 62, 0)
MindFlaySparkling3:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
MindFlaySparkling3:SetWidth(10)
MindFlaySparkling3:SetHeight(40)
MindFlaySparkling3:SetBlendMode("ADD")
MindFlaySparkling3:Hide()

local ShadowUpdateFrame = CreateFrame("Frame")
ShadowUpdateFrame:SetScript("OnUpdate", function(self, elapsed)
	if GetSpellCooldown("Mind Blast") ~= GetSpellCooldown("Inner Fire") or MindBlastCooldownFont:GetText() ~= "" then
		local start, dur = GetSpellCooldown("Mind Blast")
		MindBlastCooldown:SetCooldown(start, dur)
		if dur > 2 then
			MindBlastCooldownFont:SetText(start + dur - GetTime() - ((start + dur - GetTime()) % 0.1))
		else
			MindBlastCooldownFont:SetText("")
		end
	end
	if GetSpellCooldown("Shadow Word: Death") ~= GetSpellCooldown("Inner Fire") or SWDCooldownFont:GetText() ~= "" then
		local start, dur = GetSpellCooldown("Shadow Word: Death")
		SWDCooldown:SetCooldown(start, dur)
		if dur > 2 then
			SWDCooldownFont:SetText(start + dur - GetTime() - ((start + dur - GetTime()) % 0.1))
		else
			SWDCooldownFont:SetText("")
		end
	end
	if UnitExists("target") then
		local start, dur = GetSpellCooldown("Shadow Word: Death")
		SWDCooldown:SetCooldown(start, dur)
		local checkVP = 0
		local checkSWP = 0
		local checkMF = 0
		for i=1,40 do
			if select(1, UnitDebuff("target", i)) ~= nil then
				local spellName, _, _, _, _, spellDur, spellTimer = UnitDebuff("target", i)
				if spellName == "Vampiric Touch" then
					VampiricTouchStatusBar:SetValue(spellTimer/spellDur)
					checkVP = 1
				end
				if spellName == "Shadow Word: Pain" then
					SWPStatusBar:SetValue(spellTimer/spellDur)
					checkSWP = 1
				end
				if spellName == "Mind Flay" and spellTimer ~= nil then
					MindFlayStatusBar:SetValue(spellTimer/spellDur)
					if not MindFlaySparkling1:IsShown() then
						MindFlaySparkling1:Show()
						MindFlaySparkling2:Show()
						MindFlaySparkling3:Show()
					end
					checkMF = 1
				end
			else
				if checkVP == 0 and VampiricTouchStatusBar:GetValue() ~= 0 then
					VampiricTouchStatusBar:SetValue(0)
				end
				if checkSWP == 0 and SWPStatusBar:GetValue() ~= 0 then
					SWPStatusBar:SetValue(0)
				end
				if checkMF == 0 then
					MindFlayStatusBar:SetValue(0)
					if MindFlaySparkling1:IsShown() then
						MindFlaySparkling1:Hide()
						MindFlaySparkling2:Hide()
						MindFlaySparkling3:Hide()
					end
				end
				break
			end
		end
	else
		VampiricTouchStatusBar:SetValue(0)
		SWPStatusBar:SetValue(0)
		MindFlayStatusBar:SetValue(0)
		if MindFlaySparkling1:IsShown() then
			MindFlaySparkling1:Hide()
			MindFlaySparkling2:Hide()
			MindFlaySparkling3:Hide()
		end
	end
end)