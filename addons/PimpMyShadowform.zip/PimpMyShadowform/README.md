# PimpMyShadowform
<p align="left">
  <img src="https://i.imgur.com/GzcWTrl.png" width="400"/>
</p>

PimpMyShadowform is a TBC AddOn displaying your main shadow spells' durations and CDs. It also includes a small indication on Mind Flay damages.   

It is mainly for PvE (Shadow Priests), as it helps rotating through the five main damaging spells. You can find more information on the following EJ thread: http://web.archive.org/web/20080913120445/http://elitistjerks.com/f31/t16977-shadow_priest_101_how_melt_faces_effectively/