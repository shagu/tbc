
local mainFrame = nil
local foregroundFrame = nil
local fontFrame = nil
local fontString = nil
local highlightedTargetFrame = nil

local RobinRoles_selfPlayerName = ""

local function SetupDefaultSavedVariables()
	RobinRoles_SavedVars["mainFrameHiddenStatus"] = true
	RobinRoles_SavedVars["mainFrameLockedStatus"] = false
end

local function GetSavedVariable(var)
	if RobinRoles_SavedVars == nil then
		RobinRoles_SavedVars = {}
		SetupDefaultSavedVariables()
	end

	return RobinRoles_SavedVars[var]
end

local function SetSavedVariable(var, value)
	if RobinRoles_SavedVars == nil then
		RobinRoles_SavedVars = {}
		SetupDefaultSavedVariables()
	end

	RobinRoles_SavedVars[var] = value
end

RobinRoles_classSpecs =
{
	["Druid"] =   { [1] = "Balance",       [2] = "Feral",        [3] = "Restoration", },
	["Mage"] =    { [1] = "Arcane",        [2] = "Fire",         [3] = "Frost",       },
	["Priest"] =  { [1] = "Discipline",    [2] = "Holy",         [3] = "Shadow",      },
	["Rogue"] =   { [1] = "Assassination", [2] = "Combat",       [3] = "Subtlety",    },
	["Warrior"] = { [1] = "Arms",          [2] = "Fury",         [3] = "Protection",  },
	["Hunter"] =  { [1] = "Beastmastery",  [2] = "Marksmanship", [3] = "Survival",    },
	["Paladin"] = { [1] = "Holy",          [2] = "Protection",   [3] = "Retribution", },
	["Shaman"] =  { [1] = "Elemental",     [2] = "Enhancement",  [3] = "Restoration", },
	["Warlock"] = { [1] = "Affliction",    [2] = "Demonology",   [3] = "Destruction", },
}

function RobinRoles_GetDefenseRatingFromText(text)
	local stringToFind = "Equip: Increases defense rating by "
	local index = string.find(text, "Increases defense rating by ")
	if index ~= nil then
		text = string.gsub(text, stringToFind, "")
		text = string.gsub(text, "%.", "")
		--DEFAULT_CHAT_FRAME:AddMessage("GetDefenseRatingFromText defense found: " .. text)
		if text and text ~= "" then
			return tonumber(text)
		end
	end

	return 0
end

function RobinRoles_GetDefenseRatingFromTooltip(...)
	local totalDefense = 0

	for i = 1, select("#", ...) do
		local region = select(i, ...)
		if region and region:GetObjectType() == "FontString" then
			local text = region:GetText()
			if text then
				totalDefense = totalDefense + RobinRoles_GetDefenseRatingFromText(text)
			end
		end
	end

	return totalDefense
end

-- Called when we setting the tooltip on an item
RobinRoles_OnTooltipSetItem_Callback_Arg = 0
RobinRoles_OnTooltipSetItem_Callback_Original = nil
function RobinRoles_OnTooltipSetItem_Callback()
    -- Call the original function first
	if RobinRoles_OnTooltipSetItem_Callback_Original then
		RobinRoles_OnTooltipSetItem_Callback_Original()
	end

	-- Fetch the defense of the item
	RobinRoles_OnTooltipSetItem_Callback_Arg = 0
	if RobinItemInfoTooltip then
		RobinRoles_OnTooltipSetItem_Callback_Arg = RobinRoles_GetDefenseRatingFromTooltip(RobinItemInfoTooltip:GetRegions())
	end
end

function RobinRoles_ScanItemDefenseRating(unitTarget, inventoryItemID)
	RobinItemInfoTooltip:SetInventoryItem(unitTarget, inventoryItemID, false)
	return RobinRoles_OnTooltipSetItem_Callback_Arg
end

function RobinRoles_ScanDefenseRating(unitTarget)
	local totalDefense = 0

	for i = 1, 18 do -- Skip ammo (0)
		if i ~= 4 then -- Skip skirt
			local defense = RobinRoles_ScanItemDefenseRating(unitTarget, i)
			totalDefense = totalDefense + defense
		end
	end

	return totalDefense
end

function RobinRoles_IsTank(playerSpec)
	if playerSpec == "Protection" then -- Paladins and warriors both have the same spec name
		return true
	end

	-- Ferals will be regarded as DPS, a check for a minimum defense rating is done later to see if it is a tank
	return false
end

function RobinRoles_IsHealer(playerSpec)
	if playerSpec == "Discipline" or
	   playerSpec == "Holy" or -- Priests and paladins both have the same spec name
	   playerSpec == "Restoration" then -- Druids and shamans both have the same spec name
		return true
	end

	return false
end

RobinRoles_playerSpecs = {}
RobinRoles_playerClassAndLevels = {}
RobinRoles_playerTalents = {}
RobinRoles_playerDefense = {}
function RobinRoles_GetPlayerSpec(playerName)
	-- Check if the playername is valid
	if playerName ~= nil then
		-- Check if the spec has already been calculated
		if RobinRoles_playerSpecs[playerName] then
			-- Return the spec
			--DEFAULT_CHAT_FRAME:AddMessage("found: RobinRoles_playerSpecs[" .. playerName .. "]: " .. RobinRoles_playerSpecs[playerName])
			return RobinRoles_playerSpecs[playerName]
		end
	end

	return "Unknown"
end

function RobinRoles_GetRole(playerName, unitTarget)
	local playerSpec = RobinRoles_GetPlayerSpec(playerName)

	local role = ""
	if string.find(unitTarget, "pet") ~= nil then
		role = "DPS"
	elseif playerSpec == "Unknown" then
		role = "Unknown"
	elseif RobinRoles_IsTank(playerSpec) then
		role = "Tank"
	elseif RobinRoles_IsHealer(playerSpec) then
		role = "Healer"
	else
		role = "DPS"

		-- Check if the spec is Feral, which can also be tank
		if playerSpec == "Feral" then
			-- Check if the defense rating of the player is high enough to be a tank
			if RobinRoles_playerDefense[playerName] >= 65 then -- 350 + 65 = 415, cap as feral
				role = "Tank"
			end
		end
	end

	return role
end

RobinRoles_calculatePlayerSpecLastFetch = ""
function RobinRoles_CalculatePlayerSpec(unitTarget, playerName)
	-- Check if the playername is valid
	if playerName ~= nil then
		-- Check if the unit is a player
		if UnitIsPlayer(unitTarget) then
			-- Check if the unit is in range
			if CheckInteractDistance(unitTarget, 1) ~= nil then -- 1 is for inspect
				--DEFAULT_CHAT_FRAME:AddMessage("we are in range: " .. unitTarget .. ", " .. playerName)
				-- Calculate the spec of the player
				local x = 0
				local y = 0
				local z = 0
				local unitTargetLevel = UnitLevel(unitTarget)
				if unitTargetLevel >= 10 then
					local getForInspectedPlayer = true -- This gets the talents from the last
													   -- character NotifyInspect was called for
					if playerName == RobinRoles_selfPlayerName then -- Sometimes "player" can be "raid3" etc
						getForInspectedPlayer = false -- This gets the talents from the current player
					end

					_, _, x = GetTalentTabInfo(1, getForInspectedPlayer)
					_, _, y = GetTalentTabInfo(2, getForInspectedPlayer)
					_, _, z = GetTalentTabInfo(3, getForInspectedPlayer)

					--local numTabs = GetNumTalentTabs(getForInspectedPlayer)
					--for t=1, numTabs do
					--	DEFAULT_CHAT_FRAME:AddMessage(GetTalentTabInfo(t, getForInspectedPlayer)..":")
					--	local numTalents = GetNumTalents(t, getForInspectedPlayer)
					--	for i=1, numTalents do
					--		nameTalent, icon, tier, column, currRank, maxRank = GetTalentInfo(t, i, getForInspectedPlayer)
					--		DEFAULT_CHAT_FRAME:AddMessage("- " .. nameTalent.. ": " .. currRank.. "/" ..maxRank)
					--	end
					--end
				end

				-- Check if the target seems to have a valid class
				local unitTargetClass = UnitClass(unitTarget)
				if x + y + z > 0 and unitTargetClass then
					-- Calculate and set the spec
					if ((x > y) and (x > z)) then
						w = 1
					elseif (y > z) then
						w = 2
					else
						w = 3
					end
					local unitTargetClassSpec = RobinRoles_classSpecs[unitTargetClass][w];
					RobinRoles_playerSpecs[playerName] = unitTargetClassSpec
					RobinRoles_playerClassAndLevels[playerName] = "Level " .. unitTargetLevel .. " " .. unitTargetClass
					RobinRoles_playerTalents[playerName] = x .. "/" .. y .. "/" .. z

					RobinRoles_playerDefense[playerName] = 0
					if unitTargetClassSpec == "Feral" then
						RobinRoles_playerDefense[playerName] = RobinRoles_ScanDefenseRating(unitTarget)
						--DEFAULT_CHAT_FRAME:AddMessage("Calculated defense rating for feral: " .. RobinRoles_playerDefense[playerName])
					end

					local role = RobinRoles_GetRole(playerName, unitTarget)
					if RobinRoles_selfPlayerName ~= playerName then
						RobinRoles_calculatePlayerSpecLastFetch = ": " .. unitTargetClass .. ", " .. unitTargetClassSpec .. " (" .. x .. ", " .. y .. ", " .. z .. "), Role: " .. role
					end
					--DEFAULT_CHAT_FRAME:AddMessage("Calculated spec: " .. playerName .. ", " .. unitTargetClass .. ", " .. unitTargetClassSpec .. " (" .. x .. ", " .. y .. ", " .. z .. "), Role: " .. role)
				else
					if RobinRoles_selfPlayerName ~= playerName then
						RobinRoles_calculatePlayerSpecLastFetch = ": " .. unitTargetClass .. " (" .. x .. ", " .. y .. ", " .. z .. ")"
					end
					--DEFAULT_CHAT_FRAME:AddMessage("Spec: " .. playerName .. ", " ..  unitTargetClass .. " (" .. x .. ", " .. y .. ", " .. z .. ")")
				end
			end
		end
	end
end

RobinRoles_inspectCooldown = 0.5
RobinRoles_lastTryInspectUnitCallTime = 0
RobinRoles_lastNotifyInspectUnit = ""
RobinRoles_lastNotifyInspectUnitName = ""
RobinRoles_inspectTainted = false
function RobinRoles_TryInspectUnit(unit, playerName)
	-- Check if the unit is not the current player (we only have to inspect other players)
	if RobinRoles_selfPlayerName ~= playerName then
		-- Check if we are not on cooldown
		local currentTime = GetTime()
		if currentTime - RobinRoles_lastTryInspectUnitCallTime > RobinRoles_inspectCooldown then
			-- Check if the unit is a player
			if UnitIsPlayer(unit) then
				-- Check if the unit is in range
				if CheckInteractDistance(unit, 1) ~= nil then -- 1 is for inspect
					-- Check if we can inspect the unit
					if CanInspect(unit) then
						--DEFAULT_CHAT_FRAME:AddMessage("TryInspectUnit: " .. unit)
						--DEFAULT_CHAT_FRAME:AddMessage("Called TryInspectUnit, is now put on CD: " .. unit .. ", " .. playerName)
						RobinRoles_calculatePlayerSpecLastFetch = ""
						RobinRoles_lastTryInspectUnitCallTime = currentTime
						RobinRoles_lastNotifyInspectUnit = unit
						RobinRoles_lastNotifyInspectUnitName = playerName
						mainFrame:RegisterEvent("INSPECT_TALENT_READY")
						--DEFAULT_CHAT_FRAME:AddMessage("NotifyInspect")
						NotifyInspect(unit)
						RobinRoles_inspectTainted = false
						--DEFAULT_CHAT_FRAME:AddMessage("NotifyInspect End")
					end
				end
			end
		end
	end
end

function RobinRoles_NotifyInspectSecure()
	RobinRoles_inspectTainted = true
	--DEFAULT_CHAT_FRAME:AddMessage("RobinRoles_inspectTainted = true")
end
hooksecurefunc("NotifyInspect", RobinRoles_NotifyInspectSecure)

--local function Specific_HookSetUnit()
--	local targetPlayerName = GameTooltip:GetUnit()
--	if UnitName("mouseover") == targetPlayerName then
--		local playerName = UnitName("mouseover")
--		if playerName then
--			RobinRoles_TryInspectUnit("mouseover", playerName)
--		end
--	end
--end

function RobinRoles_TryInspectUnitLater(unit, name)
	--DEFAULT_CHAT_FRAME:AddMessage("unit: " .. unit)
	--DEFAULT_CHAT_FRAME:AddMessage("name: " .. name)
	RobinRoles_TryInspectUnit(unit, name)
end

local function SetMainFrameLockedStatus(lockedStatus)
	SetSavedVariable("mainFrameLockedStatus", lockedStatus)
	if lockedStatus == true then
		mainFrame.isSetToMovable = false
		mainFrame:EnableMouse(false)
		--mainFrame.texture:SetTexture(frameColorLocked.r, frameColorLocked.g, frameColorLocked.b, frameColorLocked.a)
	else
		mainFrame.isSetToMovable = true
		mainFrame:EnableMouse(true)
		--mainFrame.texture:SetTexture(frameColor.r, frameColor.g, frameColor.b, frameColor.a)
	end
end

function RobinRoles_HandleEvent(self, event, unit, spellName, spellRank, ...)
	-- Check if the player has entered the world or we reloaded the UI
	-- (PLAYER_ALIVE gets called on login after we have talent information)
	if event == "PLAYER_ALIVE" or event == "PLAYER_ENTERING_WORLD" then
		-- Calculate the player spec
		RobinRoles_CalculatePlayerSpec("player", RobinRoles_selfPlayerName)

	-- Check if an inspect talent is ready
	elseif event == "INSPECT_TALENT_READY" then
		--DEFAULT_CHAT_FRAME:AddMessage("INSPECT_TALENT_READY")

		if RobinRoles_inspectTainted == false then
			--DEFAULT_CHAT_FRAME:AddMessage("RobinRoles_inspectTainted = false")
			--DEFAULT_CHAT_FRAME:AddMessage("RobinRoles_lastNotifyInspectUnit: " .. RobinRoles_lastNotifyInspectUnit)
			local targetPlayerName = UnitName(RobinRoles_lastNotifyInspectUnit)
			if targetPlayerName then
				--DEFAULT_CHAT_FRAME:AddMessage("targetPlayerName: " .. targetPlayerName)
				RobinRoles_CalculatePlayerSpec(RobinRoles_lastNotifyInspectUnit, targetPlayerName)
			end
		end

		mainFrame:UnregisterEvent("INSPECT_TALENT_READY")

	-- Check if we changed the player target
	elseif event == "PLAYER_TARGET_CHANGED" then
		-- Inspect the target
		--local playerName = UnitName("target")
		--if playerName then
		--	RobinWait(0.5, RobinRoles_TryInspectUnitLater, "target", playerName)
		--end

	-- Check if we are loading the saved variables
	elseif event == "ADDON_LOADED" and unit == "RobinRoles" then
		--DEFAULT_CHAT_FRAME:AddMessage(unit .. ": Loading options...")

		local lockedStatus = GetSavedVariable("mainFrameLockedStatus")
		if lockedStatus ~= nil then
			SetMainFrameLockedStatus(lockedStatus)
		end

		local hiddenStatus = GetSavedVariable("mainFrameHiddenStatus")
		if hiddenStatus == nil or hiddenStatus == true then
			mainFrame:Hide()
			mainFrame.isSetToHidden = true
		else
			mainFrame:Show()
			mainFrame.isSetToHidden = false
		end

	end
end

function RobinRoles_OnLoad(this)
	---- Create the main frame
	mainFrame = CreateFrame("Frame", "DragFrame_RobinRoles", UIParent)
	mainFrame:SetMovable(true)
	mainFrame:EnableMouse(true)
	mainFrame:SetUserPlaced(true)
	mainFrame:SetClampedToScreen(true)
	mainFrame:RegisterForDrag("LeftButton")
	mainFrame:SetScript("OnDragStart", mainFrame.StartMoving)
	mainFrame:SetScript("OnDragStop", mainFrame.StopMovingOrSizing)
	mainFrame:SetPoint("CENTER")
	mainFrame:SetWidth(300)
	mainFrame:SetHeight(20)
	local texture1 = mainFrame:CreateTexture("ARTWORK")
	texture1:SetAllPoints()
	texture1:SetTexture(0.2, 0.2, 0.2, 1.0)
	mainFrame.texture = texture1
	mainFrame:SetFrameLevel(1)
	mainFrame.isSetToMovable = true
	mainFrame.isSetToHidden = true

	-- Register all events we need
    mainFrame:RegisterEvent("PLAYER_ALIVE")
    mainFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
    mainFrame:UnregisterEvent("INSPECT_TALENT_READY")
    mainFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
	mainFrame:RegisterEvent("ADDON_LOADED") -- Fired when saved variables are loaded
	mainFrame:SetScript("OnEvent", RobinRoles_HandleEvent)
	--GameTooltip:HookScript("OnTooltipSetUnit", Specific_HookSetUnit)

	-- Register the tooltip events
	RobinRoles_OnTooltipSetItem_Callback_Original = RobinItemInfoTooltip:GetScript("OnTooltipSetItem")
	RobinItemInfoTooltip:SetScript("OnTooltipSetItem", RobinRoles_OnTooltipSetItem_Callback)

	-- Create the foreground frame
	foregroundFrame = CreateFrame("Frame", nil, mainFrame)
	foregroundFrame:SetPoint("TOPLEFT")
	foregroundFrame:SetWidth(mainFrame:GetWidth())
	foregroundFrame:SetHeight(mainFrame:GetHeight())
	texture1 = foregroundFrame:CreateTexture("ARTWORK")
	texture1:SetAllPoints()
	texture1:SetTexture(0.8, 0.8, 0.8, 1.0)
	foregroundFrame.texture = texture1
	foregroundFrame:SetFrameLevel(2)

	-- Create the font frame
	fontFrame = CreateFrame("Frame", nil, mainFrame)
	fontFrame:SetPoint("TOPLEFT")
	fontFrame:SetWidth(mainFrame:GetWidth())
	fontFrame:SetHeight(mainFrame:GetHeight())
	texture1 = fontFrame:CreateTexture("ARTWORK")
	texture1:SetAllPoints()
	texture1:SetTexture(0, 0, 0, 0)
	fontFrame.texture = texture1
	fontFrame:SetFrameLevel(3)
	fontFrame:SetBackdrop({nil, edgeFile = "Interface\\BUTTONS\\WHITE8X8", tile = false, tileSize = 0, edgeSize = 1, insets = { left = 0, right = 0, top = 0, bottom = 0}})
	fontFrame:SetBackdropBorderColor(0,0,0)

	-- Create the font string
	fontString = fontFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	fontString:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE")
	fontString:SetVertexColor(1, 1, 1, 1)
	fontString:SetPoint("CENTER", 0, 0)

	-- Fetch the self player name
	RobinRoles_selfPlayerName = UnitName("player")
end

function RobinRoles_UpdateUnitTarget(unitTarget)
	-- Check for the spec of the player
	local playerName = UnitName(unitTarget)
	if playerName ~= nil then
		local playerRole = RobinRoles_GetRole(playerName, unitTarget)
		if playerRole == "Unknown" then
			-- Try to inspect the current unit target
			RobinRoles_TryInspectUnit(unitTarget, playerName)
		end
	end
end

function RobinRoles_UpdateRoles()
	-- Check if we are in a raid
	if UnitExists("raid1") then
		-- Update the unit targets as a raid
		--DEFAULT_CHAT_FRAME:AddMessage("We are a raid")
		for i=1, 40, 1 do
			local unitTarget = "raid" .. i
			RobinRoles_UpdateUnitTarget(unitTarget)
		end

		for i=1, 40, 1 do
			local unitTarget = "raidpet" .. i
			RobinRoles_UpdateUnitTarget(unitTarget)
		end

	-- Check if we are in a party
	elseif UnitExists("party1") then
		-- Update the unit targets as a party
		--DEFAULT_CHAT_FRAME:AddMessage("We are a party")
		RobinRoles_UpdateUnitTarget("player", dt, nil)
		for i=1, 4, 1 do
			local unitTarget = "party" .. i
			RobinRoles_UpdateUnitTarget(unitTarget)
		end

		RobinRoles_UpdateUnitTarget("pet")

		for i=1, 4, 1 do
			local unitTarget = "partypet" .. i
			RobinRoles_UpdateUnitTarget(unitTarget)
		end
	else
		-- Update the unit targets as only the player
		--DEFAULT_CHAT_FRAME:AddMessage("We are solo")
		RobinRoles_UpdateUnitTarget("player")
		RobinRoles_UpdateUnitTarget("pet")
	end
end

local debugPosition = false
function RobinRoles_UpdateUI()
	-- Get the current cooldown percentage
	local percentage = 0
	local currentTime = GetTime()
	if currentTime - RobinRoles_lastTryInspectUnitCallTime <= RobinRoles_inspectCooldown then
		percentage = (currentTime - RobinRoles_lastTryInspectUnitCallTime) / RobinRoles_inspectCooldown
	end
	if percentage <= 0.0 then
		if debugPosition == false then
			mainFrame:Hide()
		end
		percentage = 0.000001
	else
		if mainFrame.isSetToHidden == false then
			mainFrame:Show()
		end
	end

	-- Set the new width of the foreground frame
	foregroundFrame:SetWidth(mainFrame:GetWidth() * percentage)

	-- Set the color of the foreground frame to the class color of the currently inspected unit
	local playerClass, playerClassFileName = UnitClass(RobinRoles_lastNotifyInspectUnit)
	local playerClassColor = RAID_CLASS_COLORS[playerClassFileName]
	if playerClassColor then
		foregroundFrame.texture:SetTexture(playerClassColor.r, playerClassColor.g, playerClassColor.b)
	end

	-- Set the text of the font string to the last notify inspect unit name
	fontString:SetText(RobinRoles_lastNotifyInspectUnitName .. RobinRoles_calculatePlayerSpecLastFetch)
end

RobinRoles_UpdateRolesCooldownTimer = 0
function RobinRoles_OnUpdate(this, arg1)
	RobinRoles_UpdateRolesCooldownTimer = RobinRoles_UpdateRolesCooldownTimer - arg1
	if RobinRoles_UpdateRolesCooldownTimer < 0 then
		-- Update the roles
		RobinRoles_UpdateRoles()
		RobinRoles_UpdateRolesCooldownTimer = 0.1
		--DEFAULT_CHAT_FRAME:AddMessage("Updating")
	end

	-- Update the UI
	RobinRoles_UpdateUI()
end

-- Toggles the UI on and off when typing "/rr"
SLASH_TOGGLE_ROBIN_ROLES_UI1 = '/rr'
function SlashCmdList.TOGGLE_ROBIN_ROLES_UI(msg, editBox)
	if msg == "" then
		DEFAULT_CHAT_FRAME:AddMessage("Available commands: /rr lock, /rr hide, /rr show, /rr debug")
	else
		if msg == "lock" then
			if mainFrame.isSetToMovable == false then
				SetMainFrameLockedStatus(false)
			else
				SetMainFrameLockedStatus(true)
			end

		elseif msg == "show" or msg == "hide" then
			if mainFrame:IsVisible() then
				SetSavedVariable("mainFrameHiddenStatus", true)
				mainFrame:Hide()
				mainFrame.isSetToHidden = true
			else
				SetSavedVariable("mainFrameHiddenStatus", false)
				mainFrame:Show()
				mainFrame.isSetToHidden = false
			end

		elseif msg == "debug" then
			if debugPosition == false then
				debugPosition = true
				mainFrame:Show()
			else
				debugPosition = false
			end

		end
	end
end