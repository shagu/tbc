
if (GetLocale() == "frFR") then
  HealPointsBSL = { };

	HealPointsBSL.SOCKET_MSG = "<Maj clic-droit pour sertir>";
	HealPointsBSL.GEM_TYPE = "Gemme";
  HealPointsBSL.AND = "et";
  HealPointsBSL.ARMOR = "Armure"; 
  HealPointsBSL.BLUE_SOCKET = "Ch\195\163sse bleue";
  HealPointsBSL.RED_SOCKET = "Ch\195\163sse rogue";
  HealPointsBSL.YELLOW_SOCKET = "Ch\195\163sse jaune";

	HealPointsBSL.PATTERNS_SETEQUIP = {
    -- General patterns
    { pattern = "Augmente les soins prodigu\195\169s d%'un maximum de (%d+) et les d\195\169g\195\162ts d%'un maximum de %d+ pour tous les sorts et effets magiques%.", effect = "HEAL" }, 
		{ pattern = "Augmente les effets des sorts de soins de (%d+)% au maximum%.", effect = "HEAL" },
		{ pattern = "Augmente les soins prodigu\195\169s par les sorts et effets de (%d+)% au maximum%.", effect = "HEAL" }, -- ok
		{ pattern = "Augmente les d\195\169g\195\162ts et les soins produits par les sorts et effets magiques de (%d+)% au maximum%.", effect = "HEAL" }, -- ok
		{ pattern = "Rend (%d+) points de mana toutes les 5 secondes%.", effect = "MANAREG" }, -- ok
		{ pattern = "Rend (%d+) points de mana toutes les 5 sec%.", effect = "MANAREG" }, -- ok
		{ pattern = "Augmente de (%d+) le score de coup critique des sorts%.", effect = "SPELLCRITRATING"}, -- ok
		{ pattern = "Augmente le score de coup critique des sorts de (%d+)%.", effect = "SPELLCRITRATING"}, -- ok
		{ pattern = "(%d+)%% de votre vitesse de r\195\169cup\195\169ration du Mana sont actifs lorsque vous incantez%.", effect = "CASTINGREG"},

		-- Paladin sets
		{ pattern = "R\195\169duit le temps d%'incantation de votre sort Lumi\195\168re sacr\195\169e de 0%.(%d+) sec%.", effect = "TIME_HL"}, -- Tier 5, ZG

    -- Priest sets
		{ pattern = "%-0%.(%d+) sec%. au temps d%'incantation de votre sort Soins rapides%.", effect = "TIME_FH"}, -- Tier 1
		{ pattern = "Vos Soins sup\195\169rieurs soignent maintenant aussi sur la dur\195\169e %(\195\169quivalent de R\195\169novation rang (%d+)%)%.", effect = "GH_RENEW"}, -- Tier 2
		{ pattern = "Reduit le co\195\187t en mana de votre sort R\195\169novation de (%d+)%%%.", effect = "MANA_PC_RENEW"}, -- Tier 3
		{ pattern = "Augmente la dur\195\169e de votre sort R\195\169novation de (%d+) sec%.", effect = "DURATION_RENEW"}, -- AQ40

    -- Druid sets
		{ pattern = "R\195\169duit le temps d%'incantation de votre sort R\195\169tablissement de 0%.(%d+) sec%.", effect = "TIME_REGR"}, -- Tier 2
		{ pattern = "Augmente la dur\195\169e de votre sort R\195\169cup\195\169ration de (%d+) sec%.", effect = "DURATION_REJUV"}, -- Tier 2
		{ pattern = "R\195\169duit de (%d+)%% le co\195\187t en mana de vos sorts Toucher gu\195\169risseur%, R\195\169tablissement%, R\195\169cup\195\169ration et Tranquillit\195\169%.", effect = "MANA_PC_DRUID"}, -- Tier 3
		{ pattern = "En cas de r\195\169ussite critique sur un Toucher gu\195\169risseur%, vous r\195\169cup\195\169rez (%d+)%% du co\195\187t en mana du sort%.", effect = "MANA_REFUND_CRIT_HT"}, -- Tier 3

    -- Shaman sets
		{ pattern = "Apr\195\168s avoir lanc\195\169 un sort de Vague de soins ou de Vague de soins inf\195\169rieurs%, vous avez 25%% de chances de gagner un nombre de points de mana \195\169gal \195\160 (%d+)%% du co\195\187t de base du sort%.", effect = "MANA_REFUND_HWLHW"}, -- Tier 1
		{ pattern = "Votre Vague de soins soigne aussi des cibles proches suppl\195\169mentaires%. Chaque nouveau soin perd (%d+)%% d%'efficacit\195\169%, et le sort soigne jusqu%'\195\160 deux cibles suppl\195\169mentaires%.", effect = "JUMP_HW"}, -- Tier 1
		{ pattern = "Augmente de (%d+)%% le montant de points de vie rendus par Salve de gu\195\169rison aux cibles qui suivent la premi\195\168re%.", effect = "AVG_PC_JUMPS_CHAIN"}, -- Tier 2

    -- Librams
		{ pattern = "Augmente les soins prodigu\195\169s par Eclair lumineux de (%d+) au maximum%.", effect = "AVG_ABS_FOL"}, -- ok

    -- Idols
    { pattern = "Recevez un maximum de (%d+) points de mana chaque fois que vous lancez un Toucher gu\195\169risseur%.", effect = "MANA_REFUND_HT"},
    { pattern = "Augmente les soins prodigu\195\169s par R\195\169cup\195\169ration de (%d+) au maximum%.", effect = "AVG_ABS_REJUV"},

    -- Totems
		{ pattern = "Augmente les soins prodigu\195\169s par votre Vague de Soins Inf\195\169rieurs de (%d+)%.", effect = "AVG_ABS_LHW"},
	};

	HealPointsBSL.PATTERNS_GENERIC_LOOKUP = { -- must be lower case
		["\195\160 toutes les caract\195\169ristiques"] = {"INT", "SPI", "AGI"}, -- ok
		["intelligence"] = "INT", -- ok
		["esprit"] = "SPI", -- ok
    ["force"] = "STR", -- TODO: Agi

		["sorts de soins"] = "HEAL",
		["aux soins"] = "HEAL", -- ok
		["aux sorts de soins"] = "HEAL", -- ok
    ["aux d\195\169g\195\162ts des sorts"] = "HEAL", -- ok
    ["aux d\195\169g\195\162ts des sorts et aux soins"] = "HEAL", -- ok
		["d\195\169g\195\162ts et soins "] = "HEAL",
		["sorts de dommages"] = "HEAL",
    ["au score de coup critique des sorts"] = "SPELLCRITRATING", -- ok

		["mana chaque 5 sec"] = "MANAREG",
		["points de mana toutes les 5 sec"] = "MANAREG", -- ok
    ["points de mana toutes les 5 secondes"] = "MANAREG", -- ok
    ["mana toutes les 5 secondes"] = "MANAREG", -- ok
		["mana"] = "MANA",
	};

	HealPointsBSL.PATTERNS_OTHER = {
		{ pattern = "Mana chaque (%d+) per 5 sec%.", effect = "MANAREG" }, --?

		{ pattern = "Huile de sorcier mineure", effect = "HEAL", value = 8 },
		{ pattern = "Huile de sorcier inf\195\169rieure", effect = "HEAL", value = 16 },
		{ pattern = "Huile de sorcier", effect = "HEAL", value = 24 },
		{ pattern = "Huile de sorcier brillante", effect = {"HEAL", "SPELLCRIT"}, value = {36, 1} },

		{ pattern = "Huile de mana mineure", effect = "MANAREG", value = 4 },
		{ pattern = "Huile de mana inf\195\169rieure", effect = "MANAREG", value = 8 },
		{ pattern = "Huile de mana brillante", effect = { "MANAREG", "HEAL"}, value = {12, 25} },
		{ pattern = "Huile de mana excellente", effect = "MANAREG", value = 14 },

    { pattern = "%+(%d+) Soins et %+%d+ Endurance", effect = "HEAL"}, -- ok

    { pattern = "Score de critique %+%d+ et (%d+) points de mana toutes les 5 sec%.", effect = "MANAREG"}, -- ok

    { pattern = "Vitalit\195\169", effect = "MANAREG", value = 4 }, -- ok

    };
end