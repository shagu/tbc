
if (GetLocale() == "deDE") then
  HealPointsBSL = { };

 	HealPointsBSL.SOCKET_MSG = "<Zum Sockeln Shift-Rechtsklick>";
	HealPointsBSL.GEM_TYPE = "Edelstein";
  HealPointsBSL.AND = "und";
  HealPointsBSL.ARMOR = "R\195\188stung"; 
  HealPointsBSL.BLUE_SOCKET = "Blauer Sockel";
  HealPointsBSL.RED_SOCKET = "Roter Sockel";
  HealPointsBSL.YELLOW_SOCKET = "Gelber Sockel";

	HealPointsBSL.PATTERNS_SETEQUIP = {
    -- General patterns
    { pattern = "Erh\195\182ht durch s\195\164mtliche Zauber und magische Effekte verursachte Heilung um bis zu (%d+) und den verursachten Schaden um bis zu %d+%.", effect = "HEAL" }, 
		{ pattern = "Erh\195\182ht durch Zauber und magische Effekte zugef\195\188gten Schaden und Heilung um bis zu (%d+)%.", effect = "HEAL" },
		{ pattern = "Erh\195\182ht durch Zauber und Effekte verursachte Heilung um bis zu (%d+)%.", effect = "HEAL" }, -- ok
    { pattern = "Erh\195\182ht durch Zauber und magische Effekte verursachten Schaden und Heilung um bis zu (%d+)%.", effect = "HEAL"}, -- ok
		{ pattern = "Erh\195\182ht die durch Zauber und Effekte verursachte Heilung um bis zu (%d+)%.", effect = "HEAL" },
		{ pattern = "Stellt alle 5 Sek%. (%d+) Punkt%(e%) Mana wieder her%.", effect = "MANAREG" },
		{ pattern = "Stellt alle 5 Sek%. (%d+) Mana wieder her%.", effect = "MANAREG" }, -- ok
    { pattern = "Erh\195\182ht Eure kritische Zaubertrefferwertung um (%d+)%.", effect = "SPELLCRITRATING"}, -- ok
    { pattern = "Erh\195\182ht kritische Zaubertrefferwertung um (%d+)%.", effect = "SPELLCRITRATING"}, -- ok
    { pattern = "(%d+)%% Eurer Manaregeneration bleibt w\195\164hrend des Zauberwirkens bestehen%.", effect = "CASTINGREG"}, -- ok
    { pattern = "Erh\195\182ht die Heilung um bis zu (%d+)%% Eurer gesamten Intelligenz%.", effect = "HEALFROMINT" }, -- ok
    { pattern = "Euer Zauberschaden wird um (%d+)%% Eurer gesamten Intelligenz erh\195\182ht.", effect = "HEALFROMINT" }, -- ok
    { pattern = "Erh\195\182ht Zaubertempowertung um (%d+).", effect = "SPELLHASTERATING"}, -- ok

    -- Paladin sets
		{ pattern = "Verringert die Zauberzeit Eures Zaubers %'Heiliges Licht%' um 0%.(%d+) Sekunden%.", effect = "TIME_HL"}, -- ZG -- ok
    { pattern = "Erh\195\182ht die Chance auf einen kritischen Treffer mit Eurem Zauber %'Lichtblitz%' um (%d+)%%%.", effect = "CRIT_FOL"}, -- Arena -- ok
    { pattern = "Erh\195\182ht die Chance f\195\188r einen kritischen Treffer Eures Zaubers %'Heiliges Licht%' um (%d+)%%%.", effect = "CRIT_HL"}, -- Tier 6 -- ok
    { pattern = "Erh\195\182ht die Heilwirkung Eures Zaubers %'Lichtblitz%' um (%d+)%%%.", effect = "AVG_PC_FOL"}, -- Tier 6 -- ok

    -- Priest sets
		{ pattern = "Verringert die Zauberzeit f\195\188r Euren Zauber %'Blitzheilung%' um 0%.(%d+)%.", effect = "TIME_FH"}, -- Tier 1 -- ok
    { pattern = "Erh\195\182ht die Chance auf einen kritischen Treffer mit Eurem Zauber %'Gebet der Heilung%' um (%d+)%%%.", effect = "CRIT_POH"}, -- Tier 1
		{ pattern = "Euer Zauber %'Gro\195\159e Heilung%' hat nun einen zus\195\164 tzlichen Heileffekt%, der dem Zauber %'Erneuerung%' mit Rang (%d+) entspricht%.", effect = "GH_RENEW"}, -- Tier 2 -- ok
		{ pattern = "Verringert die Manakosten Eures Zaubers %'Erneuerung%' um (%d+)%%%.", effect = "MANA_PC_RENEW"}, -- Tier 3 -- ok
		{ pattern = "Erh\195\182ht die Wirkungsdauer von %'Erneuern%' um (%d+) Sekunden%.", effect = "DURATION_RENEW"}, -- AQ40 -- ok
    { pattern = "Verringert die Manakosten Eures Zaubers %'Gebet der Heilung%' um (%d+)%%%.", effect = "MANA_PC_POH"}, -- Tier 6 
    { pattern = "Erh\195\182ht die Heilwirkung Eures Zaubers %'Gro\195\159e Heilung%' um (%d+)%%%.", effect = "AVG_PC_GH"}, -- Tier 6 -- ok

    -- Druid sets
		{ pattern = "Verringert die Zauberzeit Eures Zaubers %'Nachwachsen%' um 0%.(%d+) Sekunden%.", effect = "TIME_REGR"}, -- Tier 2 -- ok
		{ pattern = "Erh\195\182ht die Dauer Eures Zaubers %'Verj\195\188ngung%' um (%d+) Sek%.", effect = "DURATION_REJUV"}, -- Tier 2 -- ok
  	{ pattern = "Verringert die Manakosten Eurer Zauber %'Heilende Ber\195\188hrung%'%, %'Nachwachsen%'%, %'Verj\195\188ngung%' und %'Gelassenheit%' um (%d+)%%%.", effect = "MANA_PC_DRUID"}, -- Tier 3 -- ok
		{ pattern = "Bei kritischen Treffern Eures Zaubers %'Heilende Ber\195\188hrung%' erhaltet Ihr (%d+)%% der Manakosten dieses Zaubers zur\195\188ck%.", effect = "MANA_REFUND_CRIT_HT"}, -- Tier 3 -- ok
    { pattern = "Erh\195\182ht die Dauer Eures Zaubers %'Nachwachsen%' um (%d+) Sek%.", effect = "DURATION_REGR"}, -- Tier 5 -- ok
    { pattern = "Erh\195\182ht die sofortige Heilung Eurer F\195\164higkeit %'Bl\195\182hendes Leben%' um (%d+)%.", effect = "AVG_BURST_LIFEBL"}, -- Tier 5 -- ok
    { pattern = "Erh\195\182ht die Heilwirkung Eures Zaubers %'Heilende Ber\195\182hrung%' um (%d+)%%%.", effect = "AVG_PC_HT"}, -- Tier 6 -- ok

    -- Shaman sets
		{ pattern = "Wenn die Zauber %'Welle der Heilung%' oder %'Geringe Welle der Heilung%' gewirkt werden%, besteht eine Chance von 25%%%, Mana zu gewinnen%. Der Managewinn entspricht (%d+)%% der Basiskosten des Zaubers%.", effect = "MANA_REFUND_HWLHW"}, -- Tier 1 -- ok
		{ pattern = "Eure Zauber %'Welle der Heilung%' springen auf bis zu zwei zus\195\164tzliche Ziele \195\188ber%. Bei jedem Sprung reduziert sich die Effektivit\195\164t der Heilung um (%d+)%%%.", effect = "JUMP_HW"}, -- Tier 1 -- ok
		{ pattern = "Erh\195\182ht den durch %'Kettenheilung%' geheilten Wert bei jedem Ziel nach dem ersten um (%d+)%%%.", effect = "AVG_PC_JUMPS_CHAIN"}, -- Tier 2 -- ok
		{ pattern = "Die Zauberzeit von %'Kettenheilung%' wird um 0%.(%d+) Sekunden reduziert%.", effect = "TIME_CHAIN"}, -- AQ40 -- ok
    { pattern = "Verringert die Manakosten Eures Zaubers %'Geringe Welle der Heilung%' um (%d+)%%%.", effect = "MANA_PC_LHW"}, -- Tier 5 -- ok
    { pattern = "Eure Zauber %'Kettenheilung%' kostet (%d+)%% weniger Mana%.", effect = "MANA_PC_LHW"}, -- Tier 6
    { pattern = "Erh\195\182ht den durch Euren Zauber %'Kettenheilung%' geheilten Wert um (%d+)%%%.", effect = "AVG_PC_CHAIN"}, -- Tier 6

    -- Librams
		{ pattern = "Erh\195\182ht durch %'Lichtblitz%' verursachte Heilung um bis zu (%d+)%.", effect = "AVG_ABS_FOL"}, -- ok
    { pattern = "Erh\195\182ht die durch %'Segen des Lichts%' gew\195\164hrte Extraheilung f\195\188r %'Heiliges Licht%' und %'Lichtblitz%' um (%d+)%.", effect = "AVG_ABS_BOL"}, -- ok
    { pattern = "Erh\195\182ht die von %'Heiliges Licht%' verursachte Heilung um bis zu (%d+)%.", effect = "AVG_ABS_HL"}, -- ok
    { pattern = "Verringert die Manakosten Eures Zaubers %'Heiliges Licht%' um (%d+)%.", effect = "MANA_ABS_HL"}, -- ok

    -- Idols
		{ pattern = "Erh\195\182ht den durch Euren Zauber %'Heilende Ber\195\188hrung%' geheilten Wert um (%d+).", effect = "AVG_ABS_HT"}, -- ok
    { pattern = "Jedes Mal%, wenn Ihr %'Heilende Ber\195\188hrung%' wirkt%, erhaltet ihr bis zu (%d+) Mana zur\195\188ckerstattet%.", effect = "MANA_REFUND_HT"}, -- ok
    { pattern = "Erh\195\182ht die abschlie\195\159ende Heilung von %'Bl\195\188hendes Leben%' um (%d+)%.", effect = "AVG_BURST_LIFEBL"}, -- ok
		{ pattern = "Erh\195\182ht die Heilwirkung Eures Zaubers %'Verj\195\188ngung%' um bis zu (%d+)%.", effect = "AVG_ABS_REJUV"}, -- ok
		{ pattern = "Erh\195\182ht die regelm\195\164\195\159ige Heilung von %'Bl\195\188hendes Leben%' um bis zu (%d+)%.", effect = "AVG_HOT_LIFEBL"}, -- ok
		{ pattern = "Verringert die Manakosten des Zaubers %'Nachwachsen%' um (%d+)%.", effect = "MANA_ABS_REGR"}, -- ok

    -- Totems
    { pattern = "Jedes Mal%, wenn Ihr %'Geringe Welle der Heilung%' wirkt%, erhaltet ihr bis zu (%d+) Mana zur\195\188ck%.", effect = "MANA_REFUND_LHW"}, -- ok
    { pattern = "Erh\195\182ht den von %'Kettenheilung%' geheilten Grundwert um (%d+)%.", effect = "AVG_ABS_CHAIN"}, -- ok
		{ pattern = "Erh\195\182ht die durch %'Geringe Welle der Heilung%' verursachte Heilung um bis zu (%d+)%.", effect = "AVG_ABS_LHW"}, -- ok
    { pattern = "Verringert die Manakosten Eures Zaubers %'Welle der Heilung%' um (%d+)%.", effect = "MANA_ABS_HW"}, -- ok
    { pattern = "Erh\195\182ht den durch %'Welle der Heilung%' geheilten Betrag um bis zu (%d+)%.", effect = "AVG_ABS_HW"}, -- ok
};


	HealPointsBSL.PATTERNS_GENERIC_LOOKUP = { -- must be lower case
		["alle werte"] 			= {"INT", "SPI", "AGI"},
		["intelligenz"]			= "INT",
		["willenskraft"] 		= "SPI",
    ["st\195\164rke"]   = "STR", -- TODO: Agi

		["mana alle 5 sek"] 	= "MANAREG",
		["manaregeneration"]	= "MANAREG",
		["heilzauber"]			= "HEAL",
		["heilung und zauberschaden"] = "HEAL",
		["zauberschaden und heilung"] = "HEAL",
		["zauberschaden"] 		= "HEAL",
		["mana"]				= "MANA",

		["kritische zaubertrefferwertung"] = "SPELLCRITRATING",
		["heilung"] = "HEAL",
	};

	HealPointsBSL.PATTERNS_OTHER = {
		{ pattern = "Manaregeneration (%d+) per 5 Sek%.", effect = "MANAREG" },
    { pattern = "Alle 5 Sek%. (%d+) Mana", effect = "MANAREG" }, -- ok

		{ pattern = "Schwaches Zauber\195\182l", effect = "HEAL", value = 8 },
		{ pattern = "Geringes Zauber\195\182l", effect = "HEAL", value = 16 },
		{ pattern = "Zauber\195\182l", effect = "HEAL", value = 24 },
		{ pattern = "Hervorragendes Zauber\195\182l", effect = {"HEAL", "SPELLCRIT"}, value = {36, 1} },

		{ pattern = "Schwaches Mana\195\182l", effect = "MANAREG", value = 4 },
		{ pattern = "Geringes Mana\195\182l", effect = "MANAREG", value = 8 },
		{ pattern = "Hervorragendes Mana\195\182l", effect = { "MANAREG", "HEAL"}, value = {12, 25} },
		{ pattern = "\195\156berragendes Mana\195\182l", effect = "MANAREG", value = 14 }, -- ok

    { pattern = "Vitalit\195\164t", effect = "MANAREG", value = 4 }, -- ok

    { pattern = "%+(%d+) Zauberschaden und geringe Bewegungstempoerh\195\182hung", effect = "HEAL"},

    { pattern = "Kritische Trefferwertung %+%d+ und alle 5 Sek%. (%d+) Mana", effect = "MANAREG"},
    { pattern = "Zaubertrefferwertung %+%d+ und alle 5 Sek%. (%d+) Mana", effect = "MANAREG"},
    { pattern = "Verteidigungswertung %+%d+ und alle 5 Sek%. (%d+) Mana", effect = "MANAREG"},
    { pattern = "%+%d+ Angriffskraft und alle 5 Sek%. (%d+) Mana", effect = "MANAREG" },
    { pattern = "Angriffskraft %+%d+ und alle 5 Sek%. (%d+) Mana", effect = "MANAREG" },
    { pattern = "Heilzauber %+(%d+) und alle 5 Sek%. (%d+) Mana", effect = { "HEAL", "MANAREG" }},
    { pattern = "%+(%d+) Heilzauber und alle 5 Sek%. (%d+) Mana", effect = { "HEAL", "MANAREG" }},
    { pattern = "Heilung %+(%d+) und alle 5 Sek%. (%d+) Mana", effect = { "HEAL", "MANAREG" }},
    { pattern = "%+(%d+) Heilung und alle 5 Sek%. (%d+) Mana", effect = { "HEAL", "MANAREG" }},
    { pattern = "Intelligenz %+(%d+) und alle 5 Sek%. (%d+) Mana", effect = { "INT", "MANAREG" }},
    { pattern = "%+(%d+) Intelligenz und alle 5 Sek%. (%d+) Mana", effect = { "INT", "MANAREG" }},
    { pattern = "Kritische Zaubertrefferwertung %+(%d+) und alle 5 Sek%. (%d+) Mana", effect = { "SPELLCRITRATING", "MANAREG" }},
	};
end