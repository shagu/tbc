
-- Localization
if (GetLocale() == "enUS" or GetLocale() == "enGB") then
  HealPointsLoc = {
	  DIV_RANK = "Rank",

  -- Buffs
    BUFF_TREELI = "Tree of Life",

	-- Paladin
	  TALENT_DIVINT = "Divine Intellect",
	  TALENT_HEALIG = "Healing Light",
	  TALENT_ILLUMI = "Illumination",
    TALENT_SANCLI = "Sanctified Light",
	  TALENT_HOLPOW = "Holy Power",
    TALENT_LIGHTG = "Light's Grace", -- ToDo: Add support?
    TALENT_HOLYGU = "Holy Guidance",

	  SPELL_FOL = "Flash of Light",
	  SPELL_HL = "Holy Light",
	  SPELL_HS = "Holy Shock",
	  SPELL_BOL = "Blessing of Light",

	-- Priest
	  TALENT_MEDITA = "Meditation",
	  TALENT_MENAGI = "Mental Agility",
	  TALENT_MENSTR = "Mental Strength",
    TALENT_ENLIGH = "Enlightenment",
	  TALENT_IMPREN = "Improved Renew",
	  TALENT_HOLSPE = "Holy Specialization",
	  TALENT_DIVFUR = "Divine Fury",
	  TALENT_IMPHEA = "Improved Healing",
    TALENT_HEAPRA = "Healing Prayers",
	  TALENT_SPIRED = "Spirit of Redemption",
	  TALENT_SPIGUI = "Spiritual Guidance",
	  TALENT_SPIHEA = "Spiritual Healing",
	  TALENT_HOLCON = "Holy Concentration",
    TALENT_EMPHEA = "Empowered Healing",
	
	  SPELL_FH = "Flash Heal",
	  SPELL_LH = "Lesser Heal",
	  SPELL_HEAL = "Heal",
	  SPELL_GH = "Greater Heal",
	  SPELL_RENEW = "Renew",
	  SPELL_POH = "Prayer of Healing",
	  SPELL_HOLYNOVA = "Holy Nova",
	  SPELL_COH = "Circle of Healing", 

	-- Druid
    TALENT_LUNGUI = "Lunar Guidance",
	  TALENT_MOONGL = "Moonglow",
    TALENT_DREAMS = "Dreamstate",
    TALENT_NURINS = "Nurturing Instinct",
	  TALENT_HEOFWI = "Heart of the Wild",
    TALENT_SURFIT = "Survival of the Fittest",
	  TALENT_NATURA = "Naturalist",
	  TALENT_INTENS = "Intensity",
	  TALENT_TRASPI = "Tranquil Spirit",
	  TALENT_IMPREJ = "Improved Rejuvenation",
	  TALENT_GIOFNA = "Gift of Nature",
    TALENT_EMPOHT = "Empowered Touch",
	  TALENT_IMPREG = "Improved Regrowth",
    TALENT_LIVSPI = "Living Spirit",
    TALENT_NATPER = "Natural Perfection",
    TALENT_EMPREJ = "Empowered Rejuvenation",
	
	  SPELL_REGR = "Regrowth",
	  SPELL_HT = "Healing Touch",
	  SPELL_REJUV = "Rejuvenation",
    SPELL_LIFEBL = "Lifebloom",

	-- Shaman
    TALENT_UNRSTO = "Unrelenting Storm",
	  TALENT_ANCKNO = "Ancestral Knowledge",
	  TALENT_IMHEWA = "Improved Healing Wave",
	  TALENT_TIDFOC = "Tidal Focus",
	  TALENT_TIDMAS = "Tidal Mastery",
	  TALENT_PURIFI = "Purification",
    TALENT_NATBLE = "Nature's Blessing",
    TALENT_IMPCHA = "Improved Chain Heal",
		
	  SPELL_LHW = "Lesser Healing Wave",
	  SPELL_HW = "Healing Wave",
	  SPELL_CHAIN = "Chain Heal",
	};

elseif (GetLocale() == "deDE") then
  HealPointsLoc = {
	  DIV_RANK = "Rang",

  -- Buffs
    BUFF_TREELI = "Baum des Lebens",

	-- Paladin
	  TALENT_DIVINT = "G\195\182ttliche Weisheit",
	  TALENT_HEALIG = "Heilendes Licht",
	  TALENT_ILLUMI = "Illumination",
    TALENT_SANCLI = "Geweihtes Licht",
	  TALENT_HOLPOW = "Heilige Macht",
    TALENT_LIGHTG = "Anmut des Lichts",
    TALENT_HOLYGU = "Heilige F\195\188hrung",

	  SPELL_FOL = "Lichtblitz",
	  SPELL_HL = "Heiliges Licht",
	  SPELL_HS = "Heiliger Schock",
	  SPELL_BOL = "Segen des Lichts",

	-- Priest
	  TALENT_MEDITA = "Meditation",
	  TALENT_MENAGI = "Mentale Beweglichkeit",
	  TALENT_MENSTR = "Mentale St\195\164rke",
    TALENT_ENLIGH = "Erleuchtung",
	  TALENT_IMPREN = "Verbesserte Erneuerung",
	  TALENT_HOLSPE = "Macht des Glaubens",
	  TALENT_DIVFUR = "G\195\182ttlicher Furor",
	  TALENT_IMPHEA = "Verbesserte Heilung",
    TALENT_HEAPRA = "Heilende Gebete", 
	  TALENT_SPIRED = "Geist der Erl\195\182sung",
	  TALENT_SPIGUI = "Geistige F\195\188hrung",
	  TALENT_SPIHEA = "Spirituelle Heilung",
	  TALENT_HOLCON = "Heilige Konzentration",
    TALENT_EMPHEA = "Machtvolle Heilung",
	
	  SPELL_FH = "Blitzheilung",
	  SPELL_LH = "Geringes Heilen",
	  SPELL_HEAL = "Heilen",
	  SPELL_GH = "Gro\195\159e Heilung",
	  SPELL_RENEW = "Erneuerung",
	  SPELL_POH = "Gebet der Heilung",
	  SPELL_HOLYNOVA = "Heilige Nova",
	  SPELL_COH = "Kreis der Heilung", 

	-- Druid
    TALENT_LUNGUI = "Weisheit des Mondes",
	  TALENT_MOONGL = "Mondschein",
    TALENT_DREAMS = "Traumzustand",
    TALENT_NURINS = "Besch\195\188tzerinstinkt",
	  TALENT_HEOFWI = "Herz der Wildnis",
    TALENT_SURFIT = "\195\156berleben der St\195\164rksten",
	  TALENT_NATURA = "Naturalist",
	  TALENT_INTENS = "Intensit\195\164t",
	  TALENT_TRASPI = "Gelassener Geist",
	  TALENT_IMPREJ = "Verbesserte Verj\195\188ngung",
	  TALENT_GIOFNA = "Geschenk der Natur",
    TALENT_EMPOHT = "Machtvolle Ber\195\188hrung",
	  TALENT_IMPREG = "Verbessertes Nachwachsen",
    TALENT_LIVSPI = "Geist des Lebens",
    TALENT_NATPER = "Vollkommenheit der Natur",
    TALENT_EMPREJ = "Machtvolle Verj\195\188ngung",
	
	  SPELL_REGR = "Nachwachsen",
	  SPELL_HT = "Heilende Ber\195\188hrung",
	  SPELL_REJUV = "Verj\195\188ngung",
    SPELL_LIFEBL = "Bl\195\188hendes Leben",

	-- Shaman
    TALENT_UNRSTO = "Unerblittlicher Sturm",
	  TALENT_ANCKNO = "Wissen der Ahnen",
	  TALENT_IMHEWA = "Verbesserte Welle der Heilung",
	  TALENT_TIDFOC = "Gezeitenfokus",
	  TALENT_TIDMAS = "Gezeitenbeherrschung",
	  TALENT_PURIFI = "L\195\164uterung",
    TALENT_NATBLE = "Segen der Natur",
    TALENT_IMPCHA = "Verbesserte Kettenheilung",

	  SPELL_LHW = "Geringe Welle der Heilung",
	  SPELL_HW = "Welle der Heilung",
	  SPELL_CHAIN = "Kettenheilung",
  };
elseif (GetLocale() == "frFR") then
  HealPointsLoc = {
	  DIV_RANK = "Rang",

  -- Buffs
    BUFF_TREELI = "Arbre de vie",

	-- Paladin
	  TALENT_DIVINT = "Intelligence divine",
	  TALENT_HEALIG = "Lumi\195\168re gu\195\169risseuse",
	  TALENT_ILLUMI = "Illumination",
    TALENT_SANCLI = "Lumi\195\168re sanctifi\195\169e",
	  TALENT_HOLPOW = "Puissance sacr\195\169e",
    TALENT_LIGHTG = "Gr\195\162ce de la lumi\195\168re",
    TALENT_HOLYGU = "Soutien sacr\195\169",

	  SPELL_FOL = "Eclair lumineux",
	  SPELL_HL = "Lumi\195\168re sacr\195\169e",
	  SPELL_HS = "Horion sacr\195\169",
	  SPELL_BOL = "B\195\169n\195\169diction de lumi\195\168re",

	-- Priest
	  TALENT_MEDITA = "M\195\169ditation",
	  TALENT_MENAGI = "Sagacit\195\169",
	  TALENT_MENSTR = "Force mentale",
    TALENT_ENLIGH = "Illumination",
	  TALENT_IMPREN = "R\195\169novation am\195\169lior\195\169e",
	  TALENT_HOLSPE = "Sp\195\169cialisation (Sacr\195\169)",
	  TALENT_DIVFUR = "Fureur divine",
	  TALENT_IMPHEA = "Soin am\195\169lior\195\169",
    TALENT_HEAPRA = "Pri\195\168res gu\195\169risseuses",
	  TALENT_SPIRED = "Esprit de r\195\169demption",
	  TALENT_SPIGUI = "Direction spirituelle",
	  TALENT_SPIHEA = "Soins spirituels",
	  TALENT_HOLCON = "Concentration sacr\195\169e",
    TALENT_EMPHEA = "Soins surpuissants",
	
	  SPELL_FH = "Soins rapides",
	  SPELL_LH = "Soins inf\195\169rieurs",
	  SPELL_HEAL = "Soins",
	  SPELL_GH = "Soins sup\195\169rieurs",
	  SPELL_RENEW = "R\195\169novation",
	  SPELL_POH = "Pri\195\168re de soins", 
	  SPELL_HOLYNOVA = "Nova sacr\195\169e",
	  SPELL_COH = "Cercle de soins",

	-- Druid
    TALENT_LUNGUI = "Soutien lunaire",
	  TALENT_MOONGL = "Lueur de la lune",
    TALENT_DREAMS = "Etat de r\195\170ve",
    TALENT_NURINS = "Instinct nourricier",
	  TALENT_HEOFWI = "Coeur de Fauve",
    TALENT_SURFIT = "Survie du plus apte",
	  TALENT_NATURA = "Naturaliste",
	  TALENT_INTENS = "Intensit\195\169",
	  TALENT_TRASPI = "Tranquilit\195\169 de l'Esprit",
	  TALENT_IMPREJ = "R\195\169cup\195\169ration am\195\169lior\195\169e",
	  TALENT_GIOFNA = "Don de la Nature",
    TALENT_EMPOHT = "Toucher surpuissant",
	  TALENT_IMPREG = "R\195\169tablissement am\195\169lior\195\169",
    TALENT_LIVSPI = "Espirt vif",
    TALENT_NATPER = "Perfection naturelle",
    TALENT_EMPREJ = "R\195\169cup\195\169ration surpuissante",
	
	  SPELL_REGR = "R\195\169tablissement",
	  SPELL_HT = "Toucher gu\195\169risseur",
	  SPELL_REJUV = "R\195\169cup\195\169ration",
    SPELL_LIFEBL = "Fleur de vie",

	-- Shaman
    TALENT_UNRSTO = "Temp\195\170te continuelle",
	  TALENT_ANCKNO = "Connaissance ancestrale",
	  TALENT_IMHEWA = "Vague de soins am\195\169lior\195\169e",
	  TALENT_TIDFOC = "Concentration des flots",
	  TALENT_TIDMAS = "Ma\195\174trise des flots",
	  TALENT_PURIFI = "Purification",
    TALENT_NATBLE = "B\195\169n\195\169diction de la nature",
    TALENT_IMPCHA = "Salve de gu\195\169rison am\195\169lior\195\169e",
		
	  SPELL_LHW = "Vague de soins mineurs",
	  SPELL_HW = "Vague de soins",
	  SPELL_CHAIN = " Salve de gu\195\169rison",
	};

elseif (GetLocale() == "esES") then
  HealPointsLoc = {
	  DIV_RANK = "Rango",

  -- Buffs
    BUFF_TREELI = "\195\129rbol de vida",

	-- Paladin
	  TALENT_DIVINT = "Intelecto divino",
	  TALENT_HEALIG = "Luz de sanaci\195\179n",
	  TALENT_ILLUMI = "Iluminaci\195\179n",
    TALENT_SANCLI = "Luz santificada",
	  TALENT_HOLPOW = "Poder Sagrado",
    TALENT_LIGHTG = "Gracia de Luz",
    TALENT_HOLYGU = "Gu韉 Sagrada",

	  SPELL_FOL = "Destello de Luz",
	  SPELL_HL = "Luz Sagrada",
	  SPELL_HS = "Choque Sagrado",
	  SPELL_BOL = "Bendici\195\179n de Luz",

	-- Priest
	  TALENT_MEDITA = "Meditaci\195\179n",
	  TALENT_MENAGI = "Agilidad mental",
	  TALENT_MENSTR = "Fortaleza mental",
    TALENT_ENLIGH = "Ilustraci\195\179n",
	  TALENT_IMPREN = "Renovar majorado",
	  TALENT_HOLSPE = "Especializaci\195\179n Sagrada",
	  TALENT_DIVFUR = "Furia divina",
	  TALENT_IMPHEA = "Sanaci\195\179n mejorada",
    TALENT_HEAPRA = "Rezos de sanaci\195\179n", 
	  TALENT_SPIRED = "Esp\195\173ritu redentor",
	  TALENT_SPIGUI = "Gu\195\173a espiritual",
	  TALENT_SPIHEA = "Sanaci\195\179n espiritual",
	  TALENT_HOLCON = "Concentraci\195\179n Sagrada",
    TALENT_EMPHEA = "Sanaci\195\179n empoderada",
	
	  SPELL_FH = "Sanaci\195\179n rel\195\161mpago",
	  SPELL_LH = "Sanaci\195\179n inferior",
	  SPELL_HEAL = "Sanar",
	  SPELL_GH = "Sanaci\195\179n superior",
	  SPELL_RENEW = "Renovar",
	  SPELL_POH = "Rezo de sanaci\195\179n",
	  SPELL_HOLYNOVA = "Nova Sagrada",
	  SPELL_COH = "C\195\173rculo de sanaci\195\179n", 

	-- Druid
    TALENT_LUNGUI = "Gu\195\173a de la Luna",
	  TALENT_MOONGL = "Resplandor lunar",
    TALENT_DREAMS = "Estado on\195\173rico",
    TALENT_NURINS = "Instinto de nutrici\195\179n",
	  TALENT_HEOFWI = "Coraz\195\179n de lo Salvaje",
    TALENT_SURFIT = "Supervivencia del m\195\161s fuerte",
	  TALENT_NATURA = "Naturalista",
	  TALENT_INTENS = "Intensidad",
	  TALENT_TRASPI = "Esp\195\173ritu sosegado",
	  TALENT_IMPREJ = "Rejuvenecimiento mejorado",
	  TALENT_GIOFNA = "Don de la Naturaleza",
    TALENT_EMPOHT = "Toque empoderado",
	  TALENT_IMPREG = "Recrecimientio mejorado",
    TALENT_LIVSPI = "Esp\195\173ritu vivo",
    TALENT_NATPER = "Perfecci\195\179n natural",
    TALENT_EMPREJ = "Rejuvenecimiento empoderado",
	
	  SPELL_REGR = "Recrecimiento",
	  SPELL_HT = "Toque de sanaci\195\179n",
	  SPELL_REJUV = "Rejuvenecimiento",
    SPELL_LIFEBL = "Flor de vida",

	-- Shaman
    TALENT_UNRSTO = "Tormenta inexorable",
	  TALENT_ANCKNO = "Conocimiento ancestral",
	  TALENT_IMHEWA = "Ola de sanaci\195\179n mejorada",
	  TALENT_TIDFOC = "Enfoque de las mareas",
	  TALENT_TIDMAS = "Dominio de las mareas",
	  TALENT_PURIFI = "Purificaci\195\179n",
    TALENT_NATBLE = "Bendici\195\179n de la Naturaleza",
    TALENT_IMPCHA = "Sanaci\195\179n en cadena mejorada",
		
	  SPELL_LHW = "Ola de sanaci\195\179n inferior",
	  SPELL_HW = "Ola de sanaci\195\179n",
	  SPELL_CHAIN = "Sanaci\195\179n en cadena",
  };

  elseif (GetLocale() == "zhCN") then
  HealPointsLoc = {
	DIV_RANK = "等级",

  -- Buffs
	BUFF_TREELI = "生命之树",

	-- Paladin
	TALENT_DIVINT = "神圣智慧",
	TALENT_HEALIG = "治疗之光",
	TALENT_ILLUMI = "启发",
	TALENT_SANCLI = "神圣光芒",
	TALENT_HOLPOW = "神圣能量",
	TALENT_LIGHTG = "光之优雅", -- ToDo: Add support?
	TALENT_HOLYGU = "神圣指引",

	  SPELL_FOL = "圣光闪现",
	  SPELL_HL = "圣光术",
	  SPELL_HS = "神圣震击",
	  SPELL_BOL = "光明祝福",-- Greater Blessing of Light

	-- Priest
	TALENT_MEDITA = "冥想",
	TALENT_MENAGI = "精神敏锐",
	TALENT_MENSTR = "心灵之力",
	TALENT_ENLIGH = "启迪",
	TALENT_IMPREN = "强化恢复",
	TALENT_HOLSPE = "神圣专精",
	TALENT_DIVFUR = "神圣之怒",
	TALENT_IMPHEA = "强化治疗术",
	TALENT_HEAPRA = "治疗祈祷",
	TALENT_SPIRED = "救赎之魂",
	TALENT_SPIGUI = "精神指引",
	TALENT_SPIHEA = "精神治疗",
	TALENT_HOLCON = "神圣专注",
	TALENT_EMPHEA = "治疗增效",
	
	  SPELL_FH = "快速治疗",
	  SPELL_LH = "次级治疗术",
	  SPELL_HEAL = "治疗术",
	  SPELL_GH = "强效治疗术",
	  SPELL_RENEW = "恢复",
	  SPELL_POH = "治疗祷言",
	  SPELL_HOLYNOVA = "神圣新星",
	  SPELL_COH = "治疗之环", 

	-- Druid
	TALENT_LUNGUI = "月神指引",
	TALENT_MOONGL = "月光",
	TALENT_DREAMS = "梦境",
	TALENT_NURINS = "治愈本能",
	TALENT_HEOFWI = "野性之心",
	TALENT_SURFIT = "适者生存",
	TALENT_NATURA = "自然主义",
	TALENT_INTENS = "强烈",
	TALENT_TRASPI = "宁静之魂",
	TALENT_IMPREJ = "强化回春术",
	TALENT_GIOFNA = "自然赐福",
	TALENT_EMPOHT = "治疗之触增效",
	TALENT_IMPREG = "强化愈合",
	TALENT_LIVSPI = "生命之魂",
	TALENT_NATPER = "天然完美",
	TALENT_EMPREJ = "回春增效	",
	
	SPELL_REGR = "愈合",
	SPELL_HT = "治疗之触",
	SPELL_REJUV = "回春术",
	SPELL_LIFEBL = "生命绽放",

	-- Shaman
	TALENT_UNRSTO = "冷酷风暴",
	TALENT_ANCKNO = "先祖知识",
	TALENT_IMHEWA = "强化治疗波",
	TALENT_TIDFOC = "潮汐集中",
	TALENT_TIDMAS = "潮汐掌握",
	TALENT_PURIFI = "净化",
	TALENT_NATBLE = "自然的祝福",
	TALENT_IMPCHA = "强化治疗链",
		
	  SPELL_LHW = "次级治疗波",
	  SPELL_HW = "治疗波",
	  SPELL_CHAIN = "治疗链",
	};
end
