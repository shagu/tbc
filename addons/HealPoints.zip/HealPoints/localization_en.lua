
if (GetLocale() == "enUS" or GetLocale() == "enGB") then
  HealPointsBSL = { };

	HealPointsBSL.SOCKET_MSG = "<Shift Right Click to Socket>";
	HealPointsBSL.GEM_TYPE = "Gem";
  HealPointsBSL.AND = "and";
  HealPointsBSL.ARMOR = "Armor";
  HealPointsBSL.BLUE_SOCKET = "Blue Socket";
  HealPointsBSL.RED_SOCKET = "Red Socket";
  HealPointsBSL.YELLOW_SOCKET = "Yellow Socket";

	HealPointsBSL.PATTERNS_SETEQUIP = {
    -- General patterns
    { pattern = "Increases healing done by up to (%d+) and damage done by up to %d+ for all magical spells and effects%.", effect = "HEAL" }, 
		{ pattern = "Increases healing done by spells and effects by up to (%d+)%.", effect = "HEAL" },
		{ pattern = "Increases damage and healing done by magical spells and effects by up to (%d+)%.", effect = "HEAL" },
		{ pattern = "Restores (%d+) mana per 5 sec%.", effect = "MANAREG" },
		{ pattern = "Restores (%d+) mana every 5 sec%.", effect = "MANAREG" },
		{ pattern = "Increases your spell critical strike rating by (%d+)%.", effect = "SPELLCRITRATING"},
		{ pattern = "Improves spell critical strike rating by (%d+)%.", effect = "SPELLCRITRATING"},
		{ pattern = "Allow (%d+)%% of your Mana regeneration to continue while casting%.", effect = "CASTINGREG"}, -- Primal Mooncloth
    { pattern = "Increases healing by up to (%d+)%% of your total Intellect%.", effect = "HEALFROMINT" }, -- Whitemend
    { pattern = "Increases spell damage by up to (%d+)%% of your total Intellect%.", effect = "HEALFROMINT" }, -- Spellfire
    { pattern = "Improves spell haste rating by (%d+)%.", effect = "SPELLHASTERATING"}, 

		-- Paladin sets
		{ pattern = "Reduces the casting time of your Holy Light spell by 0%.(%d+) sec%.", effect = "TIME_HL"}, -- ZG
    { pattern = "Increases the critical effect chance of your Flash of Light by (%d+)%%%.", effect = "CRIT_FOL"}, -- Arena
    { pattern = "Increases the critical strike chance of your Holy Light ability by (%d+)%%%.", effect = "CRIT_HL"}, -- Tier 6
    { pattern = "Increases the healing from your Flash of Light ability by (%d+)%%%.", effect = "AVG_PC_FOL"}, -- Tier 6 

    -- Priest sets
		{ pattern = "%-0%.(%d+) sec to the casting time of your Flash Heal spell%.", effect = "TIME_FH"}, -- Tier 1
    { pattern = "Increases your chance of a critical hit with Prayer of Healing by (%d+)%%%.", effect = "CRIT_POH"}, -- Tier 1
		{ pattern = "Your Greater Heals now have a heal over time component equivalent to a rank (%d+) Renew%.", effect = "GH_RENEW"}, -- Tier 2
		{ pattern = "Reduces the mana cost of your Renew spell by (%d+)%%%.", effect = "MANA_PC_RENEW"}, -- Tier 3
		{ pattern = "Increases the duration of your Renew spell by (%d+) sec%.", effect = "DURATION_RENEW"}, -- AQ40, Tier 5
    { pattern = "Reduces the mana cost of your Prayer of Healing ability by (%d+)%%%.", effect = "MANA_PC_POH"}, -- Tier 6 
    { pattern = "Increases the healing from your Greater Heal ability by (%d+)%%%.", effect = "AVG_PC_GH"}, -- Tier 6

    -- Druid sets
		{ pattern = "Reduces the casting time of your Regrowth spell by 0%.(%d+) sec%.", effect = "TIME_REGR"}, -- Tier 2
		{ pattern = "Increases the duration of your Rejuvenation spell by (%d+) sec%.", effect = "DURATION_REJUV"}, -- Tier 2
		{ pattern = "Reduces the mana cost of your Healing Touch%, Regrowth%, Rejuvenation%,  and Tranquility spells by (%d+)%%%.", effect = "MANA_PC_DRUID"}, -- Tier 3
		{ pattern = "On Healing Touch critical hits%, you regain (%d+)%% of the mana cost of the spell%.", effect = "MANA_REFUND_CRIT_HT"}, -- Tier 3
    { pattern = "Increases the duration of your Regrowth spell by (%d+) sec%.", effect = "DURATION_REGR"}, -- Tier 5
    { pattern = "Increases the final amount healed by your Lifebloom spell by (%d+)%.", effect = "AVG_BURST_LIFEBL"}, -- Tier 5
    { pattern = "Increases the healing from your Healing Touch ability by (%d+)%%%.", effect = "AVG_PC_HT"}, -- Tier 6 

    -- Shaman sets
		{ pattern = "After casting your Healing Wave or Lesser Healing Wave spell%, gives you a 25%% chance to gain Mana equal to (%d+)%% of the base cost of the spell%.", effect = "MANA_REFUND_HWLHW"}, -- Tier 1
		{ pattern = "Your Healing Wave will now jump to additional nearby targets%. Each jump reduces the effectiveness of the heal by (%d+)%%%, and the spell will jump to up to two additional targets%.", effect = "JUMP_HW"}, -- Tier 1
		{ pattern = "Increases the amount healed by Chain Heal to targets beyond the first by (%d+)%%%.", effect = "AVG_PC_JUMPS_CHAIN"}, -- Tier 2
		{ pattern = "%-0%.(%d+) seconds on the casting time of your Chain Heal spell%.", effect = "TIME_CHAIN"}, -- AQ40
    { pattern = "Reduces the cost of your Lesser Healing Wave spell by (%d+)%%%.", effect = "MANA_PC_LHW"}, -- Tier 5
    { pattern = "Your Chain Heal ability costs (%d+)%% less mana%.", effect = "MANA_PC_CHAIN"}, -- Tier 6
    { pattern = "Increases the amount healed by your Chain Heal ability by (%d+)%%%.", effect = "AVG_PC_CHAIN"}, -- Tier 6

    -- Librams
    { pattern = "Reduces the mana cost of Holy Light by (%d+).", effect = "MANA_ABS_HL"}, 
		{ pattern = "Increases healing done by Flash of Light by up to (%d+)%.", effect = "AVG_ABS_FOL"},
    { pattern = "Increases the benefit your Flash of Light spell receives from Blessing of Light by (%d+) and Holy Light spell receives from Blessing of Light by %d+%.", effect = "AVG_ABS_BOL"},
    { pattern = "Increases healing done by Holy Light by up to (%d+)%.", effect = "AVG_ABS_HL"},

    -- Idols
    { pattern = "Increases the final healing value of your Lifebloom by (%d+)%.", effect = "AVG_BURST_LIFEBL"},
    { pattern = "Reduces the mana cost of Rejuvenation by (%d+)%.", effect = "MANA_ABS_REJUV"},
		{ pattern = "Increases the amount healed by Healing Touch by (%d+)%.", effect = "AVG_ABS_HT"},
    { pattern = "Gain up to (%d+) mana each time you cast Healing Touch%.", effect = "MANA_REFUND_HT"},
		{ pattern = "Reduces the mana cost of Regrowth by (%d+)%.", effect = "MANA_ABS_REGR"},
		{ pattern = "Increases healing done by Rejuvenation by up to (%d+)%.", effect = "AVG_ABS_REJUV"},
		{ pattern = "Increases the periodic healing of your Lifebloom by up to (%d+)%.", effect = "AVG_HOT_LIFEBL"},

    -- Totems
    { pattern = "Regain up to (%d+) mana each time you cast Lesser Healing Wave.", effect = "MANA_REFUND_LHW"}, -- TODO: Implement
    { pattern = "Increases the base amount healed by Chain Heal by (%d+)%.", effect = "AVG_ABS_CHAIN"},
		{ pattern = "Increases healing done by Lesser Healing Wave by up to (%d+)%.", effect = "AVG_ABS_LHW"},
		{ pattern = "Reduces the base mana cost of Chain Heal by (%d+)%.", effect = "MANA_ABS_CHAIN"},
    { pattern = "Reduces the mana cost of Healing Wave by (%d+)%.", effect = "MANA_ABS_HW"},
    { pattern = "Increases healing done by Healing Wave by up to (%d+)%.", effect = "AVG_ABS_HW"},
 	};

	-- generic patterns have the form "+xx bonus" or "bonus +xx" with an optional % sign after the value.

	-- first the generic bonus string is looked up in the following table
	HealPointsBSL.PATTERNS_GENERIC_LOOKUP = { -- must be lower case
		["all stats"] 			= {"INT", "SPI", "AGI"},
		["intellect"]			= "INT",
		["spirit"] 				= "SPI",
    ["agility"]      = "AGI",

		["healing spells"] 		= "HEAL",
    ["healing"] = "HEAL",
		["increases healing"] 	= "HEAL",
		["healing and spell damage"] = "HEAL",
		["damage and healing spells"] = "HEAL",
		["spell damage and healing"] = "HEAL",
		["mana every 5 seconds"] 	= "MANAREG",
		["mana every 5 second"] 	= "MANAREG",
		["mana every 5 sec"] 	= "MANAREG",
		["mana per 5 seconds"] 	= "MANAREG",
		["mana per 5 sec"] 	= "MANAREG",
		["spell critical strike rating"] 	= "SPELLCRITRATING",
		["spell critical rating"] 	= "SPELLCRITRATING",
		["spell crit rating"] 	= "SPELLCRITRATING",
		["spell haste rating"] = "SPELLHASTERATING",
		["spell damage"] 		= "HEAL", -- Spell Power enchant also increase +healing (added in patch 1.12)
		["mana regen"] 			= "MANAREG",
		["mana"]				= "MANA",
	};

	-- finally if we got no match, we match against some special enchantment patterns.
	HealPointsBSL.PATTERNS_OTHER = {
		{ pattern = "Mana Regen (%d+) per 5 sec%.", effect = "MANAREG" },

		{ pattern = "Minor Wizard Oil", effect = "HEAL", value = 8 },
		{ pattern = "Lesser Wizard Oil", effect = "HEAL", value = 16 },
		{ pattern = "Wizard Oil", effect = "HEAL", value = 24 },
		{ pattern = "Brilliant Wizard Oil", effect = {"HEAL", "SPELLCRIT"}, value = {36, 1} },

		{ pattern = "Minor Mana Oil", effect = "MANAREG", value = 4 },
		{ pattern = "Lesser Mana Oil", effect = "MANAREG", value = 8 },
		{ pattern = "Brilliant Mana Oil", effect = { "MANAREG", "HEAL"}, value = {12, 25} },
		{ pattern = "Superior Mana Oil", effect = "MANAREG", value = 14 },

    { pattern = "Vitality", effect = "MANAREG", value = 4 },

    { pattern = "%+(%d+) Spell Damage and Minor Run Speed Increase", effect = "HEAL"},
  };
end
