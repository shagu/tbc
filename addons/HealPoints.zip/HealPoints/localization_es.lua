
if (GetLocale() == "esES") then
  HealPointsBSL = { };

	HealPointsBSL.SOCKET_MSG = "<May�s clic derecho para insertar>";
	HealPointsBSL.GEM_TYPE = "Gema";
  HealPointsBSL.AND = "y";
  HealPointsBSL.ARMOR = "armadura"; 
  HealPointsBSL.BLUE_SOCKET = "Ranura azul";
  HealPointsBSL.RED_SOCKET = "Renura roja";
  HealPointsBSL.YELLOW_SOCKET = "Ranura amarilla";

	HealPointsBSL.PATTERNS_SETEQUIP = {
    -- General patterns
    { pattern = "Aumenta la sanaci\195\179n que haces en hasta (%d+) p%. y el da\195\177o que infliges en hasta %d+ p%. con todos los hechizos m\195\161gicos y efectos%.", effect = "HEAL" },
		{ pattern = "Restaura (%d+) p%. de man\195\161 cada 5 s%.", effect = "MANAREG" },
    { pattern = "Aumenta la sanaci\195\179n por hechizos y efectos hasta en (%d+) p%.", effect = "HEAL" },
    { pattern = "Aumenta el da\195\177o y la sanaci\195\179n de los hechizos m\195\161gicos y los efectos hasta en (%d+) p%.", effect = "HEAL" },
    { pattern = "Aumenta tu \195\173ndice de golpe cr\195\173tico con hechizos en (%d+) p%.", effect = "SPELLCRITRATING" },
    { pattern = "Mejora tu \195\173ndice de golpe cr\195\173tico con hechizos en (%d+)%.", effect = "SPELLCRITRATING" },

		-- Paladin sets

    -- Priest sets

    -- Druid sets

    -- Shaman sets

    -- Librams
		{ pattern = "Aumenta la sanaci\195\179n hecha por Destello de Luz hasta en (%d+) p%.", effect = "AVG_ABS_FOL"},

    -- Idols

    -- Totems
	};

	HealPointsBSL.PATTERNS_GENERIC_LOOKUP = { -- must be lower case
    ["todas las estadisticas"] = { "AGI", "INT", "SPI" },
    ["fortaleza"] = "STR", -- TODO: Agi
    ["intelecto"] = "INT",
    ["esp\195\173ritu"] = "SPI",

    ["hechizos de sanaci\195\179n"] = "HEAL",
    ["da\195\177o de hechizo y sanaci\195\179n"] = "HEAL",
    ["da\195\177o de hechizo"] = "HEAL",
    ["sanaci\195\179n"] = "HEAL",
    ["man\195\161 cada 5 s"] = "MANAREG",
    ["man\195\161 por 5 s"] = "MANAREG",
    ["\195\173ndice de golpes cr\195\173ticos con hechizos"] = "SPELLCRITRATING",
	};

	HealPointsBSL.PATTERNS_OTHER = {
    { pattern = "Aceite de man\195\161 excelente", effect = "MANAREG", value = 14 },

    { pattern = "Vitalidad", effect = "MANAREG", value = 4 }, -- ok

  };
end