﻿local L = AceLibrary("AceLocale-2.2"):new("GridSideIndicators")

L:RegisterTranslations("zhTW", function()
        return {
			["Top Side"] = "上",
			["Right Side"] = "右",
			["Bottom Side"] = "下",
			["Left Side"] = "左",
        } 
end)
