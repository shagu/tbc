With version 0.6 most of the code was rewritten to adapt the design of 
GridManaBars more to the idea of Grids "status<->indicator" concept.

This means the bar itself as indicator was separated from the status
which provides the mana (and color) of a unit.

So now you'll find a seperate entry for the ManaBar under "frames" and
another entry for the ManaStatus under "status".

The configuration for the bar can be found under "frames->advanced->ManaBar".

So you will propably have to reconfigure your GridManaBars.

If you have any problems you can post them in the GridManaBars thread on the 
WowAce board: http://www.wowace.com/forums/index.php?topic=7041.0