﻿local L = AceLibrary("AceLocale-2.2"):new("GridStatusGroupnumber")

L:RegisterTranslations("zhTW", function()
	return {
		["Unit Groupnumber"] = "單位小組數",
	}
end)
