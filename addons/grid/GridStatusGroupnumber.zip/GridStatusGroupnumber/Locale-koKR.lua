﻿local L = AceLibrary("AceLocale-2.2"):new("GridStatusGroupnumber")

L:RegisterTranslations("koKR", function()
	return {
		["Unit Groupnumber"] = "파티 번호",
	}
end)
