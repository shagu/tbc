﻿local L = AceLibrary("AceLocale-2.2"):new("GridStatusGroupnumber")

L:RegisterTranslations("enUS", function()
	return {
		["Unit Groupnumber"] = true,
	}
end)
