﻿local L = AceLibrary("AceLocale-2.2"):new("GridStatusGroupnumber")

L:RegisterTranslations("zhCN", function()
	return {
		["Unit Groupnumber"] = "单位小组数",
	}
end)
