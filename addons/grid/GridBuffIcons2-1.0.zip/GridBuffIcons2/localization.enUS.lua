local L = AceLibrary("AceLocale-2.2"):new("GridBuffIcons2")

L:RegisterTranslations("enUS", function() return {
	["Buff Icons2"] = true,

	["Show Buff instead of Debuff"] = true,
	["If selected, the icons will present unit buffs instead of debuffs."] = true,

	["Only castable/removable"] = true,
	["If selected, only shows the buffs you can cast or the debuffs you can remove."] = true,
	
	["Icons Size"] = true,
	["Size for each buff icon"] = true,
	
	["Offset X"] = true,
	["X-axis offset from the selected anchor point, minus value to move inside."] = true,

	["Offset Y"] = true,
	["Y-axis offset from the selected anchor point, minus value to move inside."] = true,

	["Alpha"] = true,
	["Alpha value for each buff icon"] = true,

	["Icon Numbers"] = true,
	["Max icons to show."] = true,
	["Icons Per Row"] = true,
	["Sperate icons in several rows."] = true,

	["Orientation of Icon"] = true,
	["Set icons list orientation."] = true,
	["VERTICAL"] = true,
	["HORIZONTAL"] = true,

	["Anchor Point"] = true,
	["Anchor point of the first icon."] = true,
	["TOPRIGHT"] = true,
	["TOPLEFT"] = true,
	["BOTTOMLEFT"] = true,
	["BOTTOMRIGHT"] = true,
} end)
