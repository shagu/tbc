﻿local L = AceLibrary("AceLocale-2.2"):new("GridStatusParty")

L:RegisterTranslations("deDE", function()
	return {
		["Party Flags"] = "Gruppensymbole",
		["Party: Party Leader"] = "Gruppe: Gruppenleiter",
		["Party: Raid Leader"] = "Gruppe: Schlachtzugsleiter",
		["Party: Raid Assistant"] = "Gruppe: Schlachtzugsassistent",
		["Party: Master Looter"] = "Gruppe: Plündermeister",
    ["PL"] = "GL", -- Party Leader
    ["RL"] = "SL", -- Raid Leader
    ["RA"] = "SA", -- Raid Assistant
    ["ML"] = "PM", -- Master Looter
	}
end)