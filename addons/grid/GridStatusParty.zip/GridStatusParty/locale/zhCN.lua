local L = AceLibrary("AceLocale-2.2"):new("GridStatusParty")

L:RegisterTranslations("zhCN", function()
	return {
		["Party Flags"] = "队伍定义",
		["Party: Party Leader"] = "小队：队长",
		["Party: Raid Leader"] = "团队：团队领袖",
		["Party: Raid Assistant"] = "团队：团队助理",
		["Party: Master Looter"] = "团队：团队拾取",
    ["PL"] = "PL", -- Party Leader
    ["RL"] = "RL", -- Raid Leader
    ["RA"] = "RA", -- Raid Assistant
    ["ML"] = "ML", -- Master Looter
	}
end)