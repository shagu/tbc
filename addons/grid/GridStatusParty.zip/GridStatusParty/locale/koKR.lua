local L = AceLibrary("AceLocale-2.2"):new("GridStatusParty")

L:RegisterTranslations("koKR", function()
	return {
		["Party Flags"] = "파티 깃발",
		["Party: Party Leader"] = "파티장",
		["Party: Raid Leader"] = "공격대장",
		["Party: Raid Assistant"] = "부공격대장",
		["Party: Master Looter"] = "담당자 획득",
    ["PL"] = "PL", -- Party Leader
    ["RL"] = "RL", -- Raid Leader
    ["RA"] = "RA", -- Raid Assistant
    ["ML"] = "ML", -- Master Looter
	}
end)