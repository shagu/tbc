﻿local L = AceLibrary("AceLocale-2.2"):new("GridStatusParty")

L:RegisterTranslations("enUS", function()
	return {
		["Party Flags"] = true,
		["Party: Party Leader"] = true,
		["Party: Raid Leader"] = true,
		["Party: Raid Assistant"] = true,
		["Party: Master Looter"] = true,
    ["PL"] = true, -- Party Leader
    ["RL"] = true, -- Raid Leader
    ["RA"] = true, -- Raid Assistant
    ["ML"] = true, -- Master Looter
	}
end)