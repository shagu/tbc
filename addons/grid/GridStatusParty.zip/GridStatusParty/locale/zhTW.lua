local L = AceLibrary("AceLocale-2.2"):new("GridStatusParty")

L:RegisterTranslations("zhTW", function()
	return {
		["Party Flags"] = "隊伍定義",
		["Party: Party Leader"] = "小隊：隊長",
		["Party: Raid Leader"] = "團隊：團隊領袖",
		["Party: Raid Assistant"] = "團隊：團隊助理",
		["Party: Master Looter"] = "團隊：團隊拾取",
    ["PL"] = "PL", -- Party Leader
    ["RL"] = "RL", -- Raid Leader
    ["RA"] = "RA", -- Raid Assistant
    ["ML"] = "ML", -- Master Looter
	}
end)