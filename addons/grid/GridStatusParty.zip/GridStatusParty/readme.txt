GridStatusParty
(c) Byron Shelden, Kyle Smith

GSP is a grid status plugin that provides status indicatrs for party flags:
 * Party Leader (light blue box or "PL" text)
 * Raid Leader (tan box or "RL" text)
 * Raid Assistant (yellow box or "RA" text)
 * Master Looter (white box or "ML" text)

Known Issues
 * The indicators do not provide an icon, only color box and text
 
Any questions, concerns, or bug reports should be directed at Dashkal in #wowace
irc://irc.freenode.net/#wowace

Many thanks to Pastamancer for his assistance getting this working!
