﻿-- ----------------------------------------------------------------------------
-- Localization for GridStatusRaidIcons
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusRaidIcons")

L:RegisterTranslations("enUS", function() return {
	["Raid Icons"] = true,
	["Raid Icons: Player"] = true,
	["Raid Icons: Player Target"] = true,

	["Star"] = true,
	["Circle"] = true,
	["Diamond"] = true,
	["Triangle"] = true,
	["Moon"] = true,
	["Square"] = true,
	["X"] = true,
	["Skull"] = true,
} end)