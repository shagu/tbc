﻿-- ----------------------------------------------------------------------------
-- Localization for GridStatusRaidIcons
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusRaidIcons")

L:RegisterTranslations("koKR", function() return {
	["Raid Icons"] = "공격대 아이콘",
	["Raid Icons: Player"] = "공격대 아이콘: 플레이어",
	["Raid Icons: Player Target"] = "공격대 아이콘: 플레이어의 대상",

	["Star"] = "별",
	["Circle"] = "동그라미",
	["Diamond"] = "다이아몬드",
	["Triangle"] = "세모",
	["Moon"] = "달",
	["Square"] = "네모",
	["X"] = "가위표",
	["Skull"] = "해골",
} end)