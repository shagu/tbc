﻿-- ----------------------------------------------------------------------------
-- Localization for GridStatusRaidIcons
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusRaidIcons")

L:RegisterTranslations("deDE", function() return {
	["Raid Icons"] = "Raid Icons",
	["Raid Icons: Player"] = "Raid Icons: Spieler",
	["Raid Icons: Player Target"] = "Raid Icons: Spielerziel",

	["Star"] = "Stern",
	["Circle"] = "Kreis",
	["Diamond"] = "Diamant",
	["Triangle"] = "Dreieck",
	["Moon"] = "Mond",
	["Square"] = "Quadrat",
	["X"] = "X",
	["Skull"] = "Totenkopf",
} end)