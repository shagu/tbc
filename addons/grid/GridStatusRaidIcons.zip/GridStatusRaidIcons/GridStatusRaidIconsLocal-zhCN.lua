﻿-- ----------------------------------------------------------------------------
-- Localization for GridStatusRaidIcons
-- by [cwdg] yleaf yaroot@gmail.com [cwowaddon.com]
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusRaidIcons")

L:RegisterTranslations("zhCN", function() return {
	["Raid Icons"] = "团队标记",
	["Raid Icons: Player"] = "团队标记：队员",
	["Raid Icons: Player Target"] = "团队标记：队员的目标",

	["Star"] = "星星",
	["Circle"] = "圆圈",
	["Diamond"] = "菱形",
	["Triangle"] = "三角",
	["Moon"] = "月亮",
	["Square"] = "方块",
	["X"] = "红叉",
	["Skull"] = "骷髅",
} end)