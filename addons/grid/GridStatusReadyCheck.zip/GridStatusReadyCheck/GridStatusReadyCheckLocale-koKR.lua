local L = AceLibrary("AceLocale-2.2"):new("GridStatusReadyCheck")

L:RegisterTranslations("koKR", function() return {
	["ReadyCheck"] = "전투 준비",
} end)
