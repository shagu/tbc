local L = AceLibrary("AceLocale-2.2"):new("GridStatusReadyCheck")

L:RegisterTranslations("enUS", function() return {
	["ReadyCheck"] = true,
	["?"] = true,
	["R"] = true,
	["X"] = true,
} end)
