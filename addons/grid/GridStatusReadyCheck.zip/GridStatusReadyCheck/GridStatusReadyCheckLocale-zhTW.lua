local L = AceLibrary("AceLocale-2.2"):new("GridStatusReadyCheck")

L:RegisterTranslations("zhTW", function() return {
	["ReadyCheck"] = "檢查就緒",
} end)
