local L = AceLibrary("AceLocale-2.2"):new("GridStatusReadyCheck")

L:RegisterTranslations("zhCN", function() return {
	["ReadyCheck"] = "检查就绪",
} end)
