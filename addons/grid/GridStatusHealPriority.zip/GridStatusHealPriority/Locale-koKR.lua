﻿local L = AceLibrary("AceLocale-2.2"):new("GridStatusHealPriority")

L:RegisterTranslations("koKR", function()
        return {
		["HealPriority"] = "치유 순위",
		["1st"] = "첫째",
		["2nd"] = "둘째",
		["Heal Priority: 1st"] = "치유 순서: 첫째",
		["Heal Priority: 2nd"] = "치유 순서: 둘째",

		["Brood Affliction: Green"] = "혈족의 고통: 녹",
		["Mortal Cleave"] = "죽음의 회전베기",
		["Gehennas\' Curse"] = "게헨나스의 저주",
		["Veil of Shadow"] = "암흑의 장막",
		["Necrotic Poison"] = "부패의 독",
		["Soul Strike"] = "영혼의 일격",
		["Solar Strike"] = "태양의 일격",
		["Magma-Thrower\'s Curse"] = "용암투척병의 저주",
		["Carrion Swarm"] = "흡혈박쥐 떼",
		["Mortal Wound"] = "죽음의 상처",
		["Enfeeble"] = "쇠약",
		["Aura of Suffering"] = "고뇌의 오라",
		["Petrification"] = "석화",
        }
end)
