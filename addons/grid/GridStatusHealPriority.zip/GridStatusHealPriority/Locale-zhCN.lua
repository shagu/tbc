﻿local L = AceLibrary("AceLocale-2.2"):new("GridStatusHealPriority")

L:RegisterTranslations("zhCN", function()
	return {
		["HealPriority"] = "治疗者",
		["1st"] = "第一",
		["2nd"] = "第二",
		["Heal Priority: 1st"] = "治疗：第一优先",
		["Heal Priority: 2nd"] = "治疗：第二优先",

		["Brood Affliction: Green"] = "龙血之痛：绿",
		["Mortal Cleave"] = "致死顺劈",
		["Gehennas\' Curse"] = "基赫纳斯的诅咒",
		["Veil of Shadow"] = "暗影迷雾",
		["Necrotic Poison"] = "死灵之毒",
		["Soul Strike"] = "灵魂打击",
		["Solar Strike"] = "恒星之击",
		["Magma-Thrower\'s Curse"] = "熔岩投掷者的诅咒",
		["Carrion Swarm"] = "腐臭蜂群",
		["Mortal Wound"] = "重伤",
		["Enfeeble"] = "削弱",
		["Aura of Suffering"] = "受难光环",
		["Petrification"] = "石化",
	}
end)