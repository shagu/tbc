﻿local L = AceLibrary("AceLocale-2.2"):new("GridStatusHealPriority")

L:RegisterTranslations("enUS", function()
	return {
		["HealPriority"] = true,
		["1st"] = true,
		["2nd"] = true,
		["Heal Priority: 1st"] = true,
		["Heal Priority: 2nd"] = true,

		["Brood Affliction: Green"] = true,
		["Mortal Cleave"] = true,
		["Gehennas\' Curse"] = true,
		["Veil of Shadow"] = true,
		["Necrotic Poison"] = true,
		["Soul Strike"] = true,
		["Solar Strike"] = true,
		["Magma-Thrower\'s Curse"] = true,
		["Carrion Swarm"] = true,
		["Mortal Wound"] = true,
		["Enfeeble"] = true,
		["Aura of Suffering"] = true,
		["Petrification"] = true,
	}
end)
