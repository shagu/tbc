﻿local L = AceLibrary("AceLocale-2.2"):new("GridStatusHealPriority")

L:RegisterTranslations("zhTW", function()
	return {
		["HealPriority"] = "治療建議",
		["1st"] = "第一",
		["2nd"] = "第二",
		["Heal Priority: 1st"] = "治療第一優先",
		["Heal Priority: 2nd"] = "治療第二優先",
		
		["Brood Affliction: Green"] = "龍血之痛:綠",
		["Mortal Cleave"] = "致死順劈",
		["Gehennas\' Curse"] = "基赫納斯的詛咒",
		["Veil of Shadow"] = "暗影迷霧",
		["Necrotic Poison"] = "墓地毒",
		["Soul Strike"] = "靈魂打擊",
		["Solar Strike"] = "熱能打擊",
		["Magma-Thrower\'s Curse"] = "熔岩投擲者的詛咒",
		["Carrion Swarm"] = "腐肉成群",
		["Mortal Wound"] = "致死重傷",
		["Enfeeble"] = "削弱",
		["Aura of Suffering"] = "苦難光環",
		["Petrification"] = "石化",
	}
end)