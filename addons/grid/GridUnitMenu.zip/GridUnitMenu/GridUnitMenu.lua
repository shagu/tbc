-- create a popup (hell can't I just use the same that blizz are using :-/)
CreateFrame("Frame", "GridUnitMenuPopup", UIParent, "UIDropDownMenuTemplate");

local menu = function(self)
	if GetNumRaidMembers() > 0 then
	-- I'm in a raid
		UnitPopup_ShowMenu(GridUnitMenuPopup, "RAID_PLAYER", GridUnitMenuPopup.unit);
	elseif GetNumPartyMembers() > 0 then
	-- I'm in a party
		UnitPopup_ShowMenu(GridUnitMenuPopup, "PARTY", GridUnitMenuPopup.unit);
	else
	-- I'm alone :(
		UnitPopup_ShowMenu(GridUnitMenuPopup, "SELF", GridUnitMenuPopup.unit);
	end
end
UIDropDownMenu_Initialize(GridUnitMenuPopup, menu, "MENU");

-- Grid starting r68458, the function GridFrame_OnLoad was renamed AND made
-- local, though the new method of registering the menu should work with the old
-- version too!
if GridFrame.RegisterFrame then
	-- posthook this into the grid button register function
	hooksecurefunc(GridFrame, "RegisterFrame", function(self, frame)
		if not frame.menu then
			frame.menu = function()
				GridUnitMenuPopup.unit = frame.unit;
				ToggleDropDownMenu(1, nil, GridUnitMenuPopup, frame:GetName(), 0, 0);
			end
		end
		frame:SetAttribute("type2", "menu");
	end);
else
	DEFAULT_CHAT_FRAME:AddMessage("|cFFFF5555Can't load GridUnitMenu, you may "
		.."be using an incompatible (new?) version of Grid, please contact the "
		.."developer on the GridUnitMenu page or via PM on wow.curse.com!|n"
		.."Sorry.");
end	

