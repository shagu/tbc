﻿-- ----------------------------------------------------------------------------
-- Localization for GridStatusMTs
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusMTs")

L:RegisterTranslations("deDE", function() return {
	["MTs"] = "MTs",

} end)