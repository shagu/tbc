﻿-- ----------------------------------------------------------------------------
-- Localization for GridStatusMTs
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusMTs")

L:RegisterTranslations("koKR", function() return {
	["MTs"] = "메인 탱커",

} end)