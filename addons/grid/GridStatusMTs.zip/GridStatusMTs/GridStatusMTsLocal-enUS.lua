﻿-- ----------------------------------------------------------------------------
-- Localization for GridStatusMTs
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusMTs")

L:RegisterTranslations("enUS", function() return {
	["MTs"] = true,

} end)