-- ----------------------------------------------------------------------------
-- Localization for GridStatusRes
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusRes")

L:RegisterTranslations("frFR", function() return {
	["Resurrection"] = "R\195\169surrection",
	["Incomming Resurrection"] = "R\195\169surrection entrante",
	["Soulstone"] = "Pierre d'\195\162me",
	["Resurrected"] = "Ressuscit\195\169"
} end)
