-- ----------------------------------------------------------------------------
-- Localization for GridStatusRes
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusRes")

L:RegisterTranslations("zhTW", function() return {
	["Resurrection"] = "復活",
	["Incomming Resurrection"] = "接受復活",
	["Soulstone"] = "靈魂石",
	["Resurrected"] = "已復活"
} end)
