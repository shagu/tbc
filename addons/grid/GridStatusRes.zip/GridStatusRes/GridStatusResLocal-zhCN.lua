-- ----------------------------------------------------------------------------
-- Localization for GridStatusRes
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusRes")

L:RegisterTranslations("zhCN", function() return {
	["Resurrection"] = "复活",
	["Incomming Resurrection"] = "接受复活",
	["Soulstone"] = "灵魂石",
	["Resurrected"] = "已复活"
} end)
