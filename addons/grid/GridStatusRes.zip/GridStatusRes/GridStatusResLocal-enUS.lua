﻿-- ----------------------------------------------------------------------------
-- Localization for GridStatusRes
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusRes")

L:RegisterTranslations("enUS", function() return {
	["Resurrection"] = true,
	["Incomming Resurrection"] = true,
	["Soulstone"] = true,
	["Resurrected"] = true
} end)
