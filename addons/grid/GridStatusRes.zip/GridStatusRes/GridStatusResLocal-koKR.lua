-- ----------------------------------------------------------------------------
-- Localization for GridStatusRes
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusRes")

L:RegisterTranslations("koKR", function() return {
	["Resurrection"] = "부활",
	["Incomming Resurrection"] = "부활 받음",
	["Soulstone"] = "영혼석",
	["Resurrected"] = "부활"
} end)
