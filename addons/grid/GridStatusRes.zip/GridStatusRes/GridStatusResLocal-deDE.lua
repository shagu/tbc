﻿-- ----------------------------------------------------------------------------
-- Localization for GridStatusRes
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridStatusRes")

L:RegisterTranslations("deDE", function() return {
	["Resurrection"] = "Wiederbelebung",
	["Incomming Resurrection"] = "Eingehende Wiederbelebung",
	["Soulstone"] = "Seelenstein",
	["Resurrected"] = "Wiederbelebt"
} end)