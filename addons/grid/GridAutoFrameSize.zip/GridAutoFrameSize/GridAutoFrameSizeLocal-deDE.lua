﻿-- ----------------------------------------------------------------------------
-- Localization for GridAutoFrameSize
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridAutoFrameSize")

L:RegisterTranslations("deDE", function() return {
	["Auto Size Raid Frame"] = "Automatische Frame Größe",
	["Automatically adjusts frame layout to raid size"] = "Passt den Frame automatisch an die Raidgröße an",
	["Use predefined zone size"] = "Zonen Frame Größe",
	["Automatically adjust size of the layout to the zone you enter and locks it so it doesnt get resized when groups are changed. e.g. Black Temple / Sunwell by Group 25"] = "Passt die Frame Größe automatisch and die betretene Zone an und blockiert die automatische veränderung bei Gruppenveränderungen.",		
} end)