﻿-- ----------------------------------------------------------------------------
-- Localization for GridAutoFrameSize
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridAutoFrameSize")

L:RegisterTranslations("zhTW", function() return {
	["Auto Size Raid Frame"] = "自動調適團隊框架",
	["Automatically adjusts frame layout to raid size"] = "依照團隊類型自動調整適合的團隊框架配置",
	["Use predefined zone size"] = "依照地區自動設定成對應的框架",
	["Automatically adjust size of the layout to the zone you enter and locks it so it doesnt get resized when groups are changed. e.g. Black Temple / Sunwell by Group 25"] = "自動依照地區自動選擇對應的框架，譬如：黑暗神廟自動選擇為25人框架",
} end)