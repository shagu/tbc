-- ----------------------------------------------------------------------------
-- Localization for GridAutoFrameSize
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridAutoFrameSize")

L:RegisterTranslations("koKR", function() return {
	["Auto Size Raid Frame"] = "공격대 창 자동 크기",
	["Automatically adjusts frame layout to raid size"] = "자동으로 크기를 공격대 창 배치로 조정합니다.",
	["Use predefined zone size"] = "미리 지정한 지역 크기 사용",
	["Automatically adjust size of the layout to the zone you enter and locks it so it doesnt get resized when groups are changed. e.g. Black Temple / Sunwell by Group 25"] = "자동적으로 배치의 크기를 당신이 입장하는 지역에 맞춥니다. 예. 검은 사원 / 태양샘 25인 공격대",
} end)