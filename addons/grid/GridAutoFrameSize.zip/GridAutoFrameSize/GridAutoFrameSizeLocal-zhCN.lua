﻿-- ----------------------------------------------------------------------------
-- Localization for GridAutoFrameSize
-- ----------------------------------------------------------------------------

local L = AceLibrary("AceLocale-2.2"):new("GridAutoFrameSize")

L:RegisterTranslations("zhCN", function() return {
	["Auto Size Raid Frame"] = "自动调整团队框体",
	["Automatically adjusts frame layout to raid size"] = "根据团队类型自动调整团队框体",
	["Use predefined zone size"] = "根据地图设定适应的框体",
	["Automatically adjust size of the layout to the zone you enter and locks it so it doesnt get resized when groups are changed. e.g. Black Temple / Sunwell by Group 25"] = "根据地区自动设定适应的框体。例如：黑暗神庙/太阳之井高地自动选择25人框体",
} end)