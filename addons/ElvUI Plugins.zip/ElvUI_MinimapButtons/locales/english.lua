﻿local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("ElvUI", "enUS", true)
if not L then return end

L["Inside Minimap"] = true
L["Minimap Button Grabber"] = true
L["Transparent Backdrop"] = true