Sell Junk is a World of Warcraft addon to sell any grey items in your inventory.  There is a global exception list as well as a character exception list.  Grey items listed on the exceptions list will not be sold.  Non-grey items listed on the exceptions list will be sold.

This addon is still in beta test mode.  Please be careful when using it.

To install:  Copy the SellJunk folder to the Interface\AddOns directory of WoW.

In game: Type /SellJunk or /sj for in-game options.