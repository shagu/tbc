if( GetLocale() == "deDE" ) then
	MBB_TOOLTIP1 = "Strg + Rechtsklick auf einen Button, um ihn aus der Leiste zu lösen.";
	MBB_OPTIONS_HEADER = "Einstellungen";
	MBB_OPTIONS_OKBUTTON = "Ok";
	MBB_OPTIONS_CANCELBUTTON = "Abbrechen";
	MBB_OPTIONS_SLIDEROFF = "Aus";
	MBB_OPTIONS_SLIDERSEK = "Sek.";
	MBB_OPTIONS_SLIDERLABEL = "Autom. ausblenden:";
	MBB_OPTIONS_EXPANSIONLABEL = "Ausklappen nach:";
	MBB_OPTIONS_EXPANSIONLEFT = "Links";
	MBB_OPTIONS_EXPANSIONTOP = "Oben";
	MBB_OPTIONS_EXPANSIONRIGHT = "Rechts";
	MBB_OPTIONS_EXPANSIONBOTTOM = "Unten";
	MBB_OPTIONS_MAXBUTTONSLABEL = "Max. Knöpfe/Zeile:";
	MBB_OPTIONS_MAXBUTTONSINFO = "(0=unendlich)";
	MBB_OPTIONS_ALTEXPANSIONLABEL = "Alt. Ausklappen nach:";
	MBB_HELP1 = "Gib \"/mbb <cmd>\" ein, wobei <cmd> folgendes sein kann:";
	MBB_HELP2 = "  |c00ffffffbuttons|r: Zeigt eine Liste aller Frames in der MBB Leiste";
	MBB_HELP3 = "  |c00ffffffreset position|r: Setzt den MBB Minimap Button an seine ursprüngliche Position";
	MBB_HELP4 = "  |c00ffffffreset all|r: Setzt alle Einstellungen auf ihre ursprünglichen Werte";
	MBB_NOERRORS = "Keine Fehler gefunden!";
end