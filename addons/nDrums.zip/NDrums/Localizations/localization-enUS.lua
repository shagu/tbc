local L = LibStub("AceLocale-3.0"):NewLocale("NDrums", "enUS", true)
if not L then return end
		
-- Following are pairs of config option and its description (mouseover)
L["Enabled"] = true
L["Enable drums logic"] = true
L["Next Drummer"] = true
L["Next player to drum"] = true
L["Audio Warning"] = true
L["Audio warns you when its time to drum"] = true
L["Configure"] = true
L["Bring up GUI configure dialog"] = true
L["Party Start Message"] = true
L["A message sent to party chat when you activate your drums"] = true
L["Party End Message"] = true
L["A message sent to party chat when your drums expire"] = true
L["Audio Volume"] = true
	L["Low"] = true
	L["Medium"] = true
	L["High"] = true
L["Audio volume level"] = true
L["Previous Drummer"] = true
L["Player who drums before you"] = true
L["Drums Type"] = true
	L["Drums of War"] = true -- Has to be exactly the same as Item's name
	L["Drums of Battle"] = true -- Has to be exactly the same as Items's name
	L["Drums of Restoration"] = true -- Has be to exactly the same as Item's name
	L["Drums of Speed"] = true -- Has be to exactly the same as Item's name
L["Types of drums you are going to use"] = true
L["BigWigs Integration"] = true
L["Uses BigWigs to track previous drummer"] = true
L["DBM Integration"] = true
L["Uses Deadly Bossmods to track previous drummer"] = true
L["Debug"] =true
L["Disable it or you can lose your harddrive"] = true
L["Whisper Message"] = true
L["A message to be whispered to the next person"] = true
L["Whisper Match"] = true
L["If a whisper message contains this, the drums notifications will be activated"] = true
L["Target"] = true
L["Set the name of your current target"] = true
L["Rotation"] = true
L["Set up drums rotation for all party members"] = true
L["Cooldowns"] = true
L["Monitors cooldowns and notifies at the time next drummer has no drums cooldown"] = true
L["Defaults"] = true
L["Resets all options to defaults"] = true

-- Other stuff
L["Drums activated!"] = "%d activated!" -- Default value for "Party Start Message"
L["Drums expired!"] = "%d expired!" -- Default value for "Party End Message"
L["Your time to drum"] = true -- BigWigs or DBM bar text
L["Drums, drums!"] = true -- BigWigs notification and default whisper text
L["drums"] = true -- Whisper match string. Make sure this is contained (case insensitive) in the default notification and whisper text
L["NDrums."] = true -- Prefix for chat messages
L["Rotation: "] = true -- Rotation announce prefix

-- Keybinding
BINDING_HEADER_NDRUMS_BINDINGS = "Narkar Drums"
BINDING_NAME_NDRUMS_ROTATION_KEY = "Rotation from target"
