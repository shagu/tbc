local L = LibStub("AceLocale-3.0"):NewLocale("NDrums", "deDE", false)
if not L then return end

-- Following are pairs of config option and its description (mouseover)
L["Enabled"] = "Eingeschaltet"
L["Enable drums logic"] = "Trommel Logic einschalten"
L["Next Drummer"] = "Naechster Trommler"
L["Next player to drum"] = "Naechster Spieler der trommeln soll"
L["Audio Warning"] = "Akustische Warnung"
L["Audio warns you when its time to drum"] = "Akustische Warnung wenn es an der Zeit ist zu trommeln"
L["Configure"] = "Konfiguration"
L["Bring up GUI configure dialog"] = "Oeffnet GUI Konfigurations Fenster"
L["Party Start Message"] = "Gruppen Anfangs Nachricht"
L["A message sent to party chat when you activate your drums"] = "Eine Nachricht die im Gruppenchannel erscheint wenn Du Deine Trommeln aktivierst"
L["Party End Message"] = "Gruppen Ende Nachricht"
L["A message sent to party chat when your drums expire"] = "Eine Nachricht die im Gruppenchannel erscheint wenn Du Deine Trommeln auslaufen"
L["Audio Volume"] = "Lautstaerke"
L["Low"] = "Niedrig"
L["Medium"] = "Mittel"
L["High"] = "Hoch"
L["Audio volume level"] = "Lautstaerken Level"
L["Previous Drummer"] = "Vorheriger Trommler"
L["Player who drums before you"] = "Spieler der vor Dir trommelt"
L["Drums Type"] = "Trommel Typen"
L["Drums of War"] = "Trommeln des Krieges"
L["Drums of Battle"] = "Trommeln der Schlacht"
L["Drums of Restoration"] = "Trommeln der Wiederherstellung"
L["Types of drums you are going to use"] = "Typen von Trommeln die benutzt werden"
L["BigWigs Integration"] = true
L["Uses BigWigs to track previous drummer"] = "Benutzt BigWings um den vorherigen Trommler herauszufinden"
L["DBM Integration"] = true
L["Uses Deadly Bossmods to track previous drummer"] = "Benutzt Deadly Bossmods um den vorherigen Trommler herauszufinden"
L["Debug"] = true
L["Disable it or you can lose your harddrive"] = "Schalte es aus oder Deine Festplatte wird geloescht"
L["Whisper Message"] = "Fluester-Nachricht"
L["A message to be whispered to the next person"] = "Eine Nachricht die dem nächsten Spieler gefluestert wird"
L["Whisper Match"] = "Fluester-Uebereinstimmung"
L["If a whisper message contains this, the drums notifications will be activated"] = "Wenn eine gefluesterte Nachricht diesen Text enthaelt wird die Trommel-Benachrichtigung aktiviert"
L["Target"] = "Ziel"
L["Set the name of your current target"] = "Uebernimmt den Namen Deines aktuellen Ziels"
L["Rotation"] = true
L["Set up drums rotation for all party members"] = "Stellt die Trommel-Rotation für alle Gruppenmitglieder ein"
L["Cooldowns"] = "Abklingzeiten"
L["Monitors cooldowns and notifies at the time next drummer has no drums cooldown"] = "Beobachtet die Cooldowns und benachrichtigt den naechsten Trommel ohne Abklingzeit"
L["Defaults"] = "Verzug"
L["Resets all options to defaults"] = "Rücksetzen alle Optionen zum Verzug"

-- Other stuff
L["Drums activated!"] = "%d activated!" -- Default value for "Party Start Message"
L["Drums expired!"] = "%d expired!" -- Default value for "Party End Message"
L["Your time to drum"] = "Ihre Zeit, um zu trommeln" -- BigWigs or DBM bar text
L["Drums, drums!"] = true -- BigWigs notification and default whisper text
L["drums"] = true -- Whisper match string. Make sure this is contained (case insensitive) in the default notification and whisper text
L["NDrums."] = true -- Prefix for chat messages
L["Rotation: "] = true -- Rotation announce prefix

-- Keybinding
BINDING_HEADER_NDRUMS_BINDINGS = "Narkar Drums"
BINDING_NAME_NDRUMS_ROTATION_KEY = "Rotation from target"