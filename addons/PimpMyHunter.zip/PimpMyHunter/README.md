# PimpMyHunter
<p align="left">
  <img src="http://i.imgur.com/5vM7bqt.png"/>
  <img src="http://i.imgur.com/67o7pnn.png"/>
  <img src="http://i.imgur.com/ZiZQJAc.png"/>
</p>

PimpMyHunter is a TBC AddOn to display your ranged attack speed on a small movable frame, and your current speed buffs with their duration at its right.   

It is mainly for PvE (MM/Surv) raiding hunters, helping you to switch between your two rotations based on your current attack speed. Here's an useful EJ thread about that: http://web.archive.org/web/20080707160252/http://elitistjerks.com/f31/t13107-hunter_shot_rotation_illustrated/

