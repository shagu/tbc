﻿local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Recount", "esES", true)
if not L then return end

-- Elsia: Need Spanish localization here...

	L["Sync"] = "Sync"
