# ManaBar
 Five Second Rule with Mana Tick

/mb or /manabar for options
