local E, L, DF = unpack(ElvUI)
local B = E:GetModule("Blizzard")

function B:KillBlizzard()

end