
coolDown.Shares = { S = { }, I = { }, C = { } }


-- Healing Potions
coolDown.Shares.C[  118] = "Interface\\Icons\\INV_Potion_54"
coolDown.Shares.C[  858] = "Interface\\Icons\\INV_Potion_54"
coolDown.Shares.C[  929] = "Interface\\Icons\\INV_Potion_54"
coolDown.Shares.C[ 1710] = "Interface\\Icons\\INV_Potion_54"
coolDown.Shares.C[ 3928] = "Interface\\Icons\\INV_Potion_54"
coolDown.Shares.C[ 4596] = "Interface\\Icons\\INV_Potion_54"
coolDown.Shares.C[13446] = "Interface\\Icons\\INV_Potion_54"
coolDown.Shares.C[17348] = "Interface\\Icons\\INV_Potion_54"
coolDown.Shares.C[17349] = "Interface\\Icons\\INV_Potion_54"
coolDown.Shares.C[18839] = "Interface\\Icons\\INV_Potion_54"
coolDown.Shares.C[22829] = "Interface\\Icons\\INV_Potion_54"

-- Mana Potions
coolDown.Shares.C[ 2455] = "Interface\\Icons\\INV_Potion_76"
coolDown.Shares.C[ 3385] = "Interface\\Icons\\INV_Potion_76"
coolDown.Shares.C[ 3827] = "Interface\\Icons\\INV_Potion_76"
coolDown.Shares.C[ 6149] = "Interface\\Icons\\INV_Potion_76"
coolDown.Shares.C[13443] = "Interface\\Icons\\INV_Potion_76"
coolDown.Shares.C[13444] = "Interface\\Icons\\INV_Potion_76"
coolDown.Shares.C[17351] = "Interface\\Icons\\INV_Potion_76"
coolDown.Shares.C[17352] = "Interface\\Icons\\INV_Potion_76"
coolDown.Shares.C[18841] = "Interface\\Icons\\INV_Potion_76"
coolDown.Shares.C[22832] = "Interface\\Icons\\INV_Potion_76"

-- Mana Stones
coolDown.Shares.C[ 5513] = "Interface\\Icons\\INV_Misc_Gem_Ruby_01"
coolDown.Shares.C[ 5514] = "Interface\\Icons\\INV_Misc_Gem_Ruby_01"
coolDown.Shares.C[ 8007] = "Interface\\Icons\\INV_Misc_Gem_Ruby_01"
coolDown.Shares.C[ 8008] = "Interface\\Icons\\INV_Misc_Gem_Ruby_01"
