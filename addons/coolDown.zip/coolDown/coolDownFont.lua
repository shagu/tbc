
local fontObject = CreateFont("coolDownFont")
fontObject:SetFont("Interface\\AddOns\\coolDown\\Fonts\\coolDownFont.ttf", 22)
fontObject:SetTextColor(1.0, 0.82, 0)
