SA_sponsors = {
	["A"] = "Official Developer of SoundAlerter",
	["B"] = "Official Sponsor of SoundAlerter",
	["C"] = "Official Contributer of SoundAlerter",
--devs
["Unholysunday"] = { ["Realm"] = "Archangel [14x] Blizzlike", ["Type"] = "A" },	
["Schaka"] = { ["Realm"] = "Next Generation", ["Type"] = "A" },	
	}
