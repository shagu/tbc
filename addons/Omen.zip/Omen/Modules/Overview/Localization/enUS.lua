local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("Omen_Overview", "enUS", true)
if not L then return end

L["Overview Mode"] = true
L["Show raid icons"] = true
L["Overview Mode\n|cffffffffShows an overview of high-threat raid members|r"] = true
