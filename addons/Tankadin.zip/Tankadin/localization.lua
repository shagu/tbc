--[[
Tankadin Loc file

If you wish to help localize this mod, please change the values listed under the enUS variables and contact me.

Maintankadin.com _Chloe
ui.incgamers.com _Chloe
Chloe@tankadinaddon.com

Credits:
-- Traducteur Fr : Robin de Tolens 
-- Version        : 1.1.0
-- Last Update   : 1/5/2008

deDE-localization: Farook, Nharezia
-- Version : 1.0.1
-- Last Update: 19/4/2008
]]--

--Do not modify the version number!
TANKADIN_VERSION            = "v1.1.1";

--Credit Strings ! DO NOT MODIFY !
TANKADIN_CREDITS_QUOTE      = "\"Indeed, the only thing better than realizing\n you're able to tank anything in the game is\nreaching the point where you no longer need prove it.\"\n - Dorvan";
TANKADIN_CREDITS_AUTHOR     = "Tankadin "..TANKADIN_VERSION.." By:\n Chloe - Detheroc - US";
TANKADIN_CREDITS_SPECIAL    = "Special Thanks to:\nhttp://www.maintankadin.failsafedesign.com\nhttp://www.wowwiki.com\n> Nharezia < Der Rat von Dalaran (EU) - German Localization\nRobin de Tolens - Les Sentinelles (EU) - French Localization\ntayedaen from wowui.incgamers.com for the 30 second warning\nThe UI and Tankadin Community as a whole for all the feedback <3";

--enUS variables / Default
TANKADIN_MISS               = "Miss";
TANKADIN_DODGE              = "Dodge";
TANKADIN_PARRY              = "Parry";
TANKADIN_BLOCK              = "Block";
TANKADIN_TOTAL              = "Avoidance";
TANKADIN_UPDOWN             = "+/-";
TANKADIN_CRUSHING           = "Crushing";
TANKADIN_BVALUE             = "Block Value";
TANKADIN_DEFENSE            = "Defense";
TANKADIN_RF                 = "Righteous Fury";
TANKADIN_RF_FADE            = "Righteous Fury fades from you."
TANKADIN_RD                 = "Righteous Defense";
TANKADIN_IMMUNE             = "immune";
TANKADIN_IMMUNE_MESSAGE     = "Taunt failed! Target is immune!";
TANKADIN_RESIST             = "resist";
TANKADIN_RESIST_MESSAGE     = "Taunt failed! Target resisted!";
TANKADIN_AS                 = "Avenger's Shield";
TANKADIN_MISS_AS            = "miss";
TANKADIN_MISS_MESSAGE       = "Avenger's Shield Missed!"
TANKADIN_BOS                = "Blessing of Salvation";
TANKADIN_GBOS               = "Greater Blessing of Salvation";
TANKADIN_AD                 = "Argent Defender";
TANKADIN_SUM                = "Ardent Defender mitigated %d damage out of %d total taken (%.2f%%), and averted %d deaths.";
TANKADIN_HSD                = "Holy SD";
TANKADIN_DATA_DM            = "DM";
TANKADIN_DATA_DM_LONG       = "Damage Mitigated";
TANKADIN_DATA_DT            = "DT";
TANKADIN_DATA_DT_LONG       = "Damage Taken";
TANKADIN_DATA_DA            = "DA";
TANKADIN_DATA_DA_LONG       = "Deaths Avoided";
TANKADIN_DATA_PERCENT       = "Percent Reduced";
TANKADIN_USAGE              = "Usage: /tankadin <option>";
TANKADIN_TOOLTIP_TITLE      = "Tankadin";
TANKADIN_TOOLTIP_SUBTITLE   = "Pally Tanking Mod";
TANKADIN_TOOLTIP_LOCKED     = "Windows are locked in place.";
TANKADIN_TOOLTIP_LEFTCLICK  = "Left-click and drag to move the window.";
TANKADIN_TOOLTIP_MINMIZE    = "Right-click to minimize and maximize the mindow";
TANKADIN_OPTIONS            = "Toggles the options panel";
TANKADIN_OPTIONS_NAME       = "Options";
TANKADIN_OPTIONS_BASIC      = "Basic Tooltip";
TANKADIN_OPTIONS_ADVANCED   = "Advanced Tooltip";
TANKADIN_OPTIONS_SHOW       = "Shows the main frame";
TANKADIN_OPTIONS_ANNOUNCE   = "Announces the AD tracker information";
TANKADIN_OPTIONS_MINIMIZE   = "Shows only the Tankadin Header";
TANKADIN_OPTIONS_LOCK       = "Locks the Tankadin Frame and Options Frame in place";
TANKADIN_OPTIONS_WARN       = "Warns when "..TANKADIN_RF.." fades";
TANKADIN_OPTIONS_ONCE       = "Flashes once when "..TANKADIN_RF.." fades";
TANKADIN_OPTIONS_ALWAYS     = "Constantly Flashes until "..TANKADIN_RF.." is reapplied";
TANKADIN_OPTIONS_MISSRES    = "Alerts your raid or party when "..TANKADIN_RD.."\nfails or "..TANKADIN_AS.." misses";
TANKADIN_OPTIONS_NOIMMUNE   = "Disables the alert for immunities";
TANKADIN_OPTIONS_ALPHA      = "Sets the transparency of the window";
TANKADIN_OPTIONS_ALPHALABEL = "Alpha";
TANKADIN_OPTIONS_ALPHAWRONG = "Alpha must be between 0 and 1";
TANKADIN_OPTIONS_SCALELABEL = "Scale";
TANKADIN_OPTIONS_DEFAULTS   = "Defaults";
TANKADIN_OPTIONS_RESET_TB   = "Reset Tables";
TANKADIN_OPTIONS_TITLE      = TANKADIN_TOOLTIP_TITLE.." "..TANKADIN_VERSION.." "..TANKADIN_OPTIONS_NAME;
TANKADIN_OPTIONS_LEFTCLICK  = "Left-click and drag to move this window.";
TANKADIN_OPTIONS_ADCLEAR    = "Clears Ardent Defender Data every fight.";
TANKADIN_OPTIONS_DONE       = "Done";
TANKADIN_OPTIONS_TAB1       = "Basic";
TANKADIN_OPTIONS_TAB2       = "AD Track";
TANKADIN_OPTIONS_TAB3       = "Colors";
TANKADIN_OPTIONS_TAB4       = "Frames";
TANKADIN_OPTIONS_TAB5       = "Announce";
TANKADIN_OPTIONS_TAB6       = "Credits";
TANKADIN_OPTIONS_BGCOLOR    = "Background Color";
TANKADIN_OPTIONS_FRAMECOLOR = "Frame Color";
TANKADIN_OPTIONS_TCOLOR     = "Text Color";
TANKADIN_OPTIONS_WARNCOLOR  = "Warning Frame Color";
TANKADIN_OPTIONS_FLASHWARN  = "Flash Frame!";
TANKADIN_OPTIONS_WARNFRAMES = "Warning Frame Types:";
TANKADIN_OPTIONS_RAD        = "Report AD";
TANKADIN_OPTIONS_RAD_S      = "Reporting AD Info to: ";
TANKADIN_OPTIONS_RISHORT    = "Report Info (S)";
TANKADIN_OPTIONS_RISHORT_S  = "Reporting Attack Table Abridged Info to: ";
TANKADIN_OPTIONS_RILONG     = "Report Info (L)";
TANKADIN_OPTIONS_RILONG_S   = "Reporting Attack Table Extended Info to: ";
TANKADIN_OPTIONS_REH        = "Report EH";
TANKADIN_OPTIONS_REH_S      = "Reporting Effective Health to: ";
TANKADIN_OPTIONS_UNKOWN_S   = "Unkown Request...";
TANKADIN_OPTIONS_CHANNELS   = "-- Channels --";
TANKADIN_OPTIONS_C_DEF      = "Default";
TANKADIN_OPTIONS_C_GUILD    = "Guild";
TANKADIN_OPTIONS_C_WT       = "Whisper Target";
TANKADIN_OPTIONS_C_CUSTOM   = "Custom Channel";
TANKADIN_OPTIONS_GROWUP     = "Makes the frames grow up out of the Tankadin Header.";
TANKADIN_OPTIONS_DEATHANN   = "Announces when Ardent Defender averts a death.";
TANKADIN_OPTIONS_DETACHAD   = "Detach AD Frame.";
TANKADIN_OPTIONS_HIDEAD     = "Hide AD Frame.";
TANKADIN_OPTIONS_DETACHRF   = "Detach RF Frame.";
TANKADIN_OPTIONS_HIDERF     = "Hide RF Frame.";
TANKADIN_OPTIONS_DETACHINFO = "Detach Info Frame.";
TANKADIN_OPTIONS_HIDEINFO   = "Hide Info Frame.";
TANKADIN_OPTIONS_HIDEHEADER = "Hide Tankadin Header and attached frames.";
TANKADIN_DEATHAVOID_MESSAGE = "Ardent Defender -!!- Death Avoided!";
TANKADIN_MESSAGE_UNLOCK     = "Tankadin frame is now unlocked.";
TANKADIN_MESSAGE_LOCK       = "Tankadin frame is now locked.";
TANKADIN_INFO_EH_BASE       = "Base Effective Health";
TANKADIN_INFO_EH_MAX        = "(10k) Effective Health";
TANKADIN_INFO_EH_MIN        = "(3k) Effective Health";
TANKADIN_INFO_EH_TDR        = "Total Damage Reduction";
TANKADIN_AD_HP_ACTIVE       = "Ardent Defender is active at";
TANKADIN_AD_HP_ABBR         = "HP";
TANKADIN_IN_COMBAT_ERROR    = "You cannot do that while in-combat.";
TANKADIN_VERSION_UPDATE     = "Your version of Tankadin has been Updated to "..TANKADIN_VERSION.." and Defaults have been set.";
TANKADIN_PLUGINSTRING       = "Currently Installed Plug-ins:";
TANKADIN_ADDON_DISABLED     = "Tankadin Disabled";

-- German
if ( GetLocale() == "deDE" ) then
   
TANKADIN_MISS               = "Verfehlen";
TANKADIN_DODGE              = "Ausweichen";
TANKADIN_PARRY              = "Parieren";
TANKADIN_BLOCK              = "Blocken";
TANKADIN_TOTAL              = "Vermeidung";
TANKADIN_UPDOWN             = "+/-";
TANKADIN_CRUSHING           = "Schmetternd";
TANKADIN_BVALUE             = "Blockwert";
TANKADIN_DEFENSE            = "Verteidigung";
TANKADIN_RF                 = "Zorn der Gerechtigkeit";
TANKADIN_RF_FADE            = "'Zorn der Gerechtigkeit' schwindet von Euch.";
TANKADIN_RD                 = "Rechtschaffene Verteidigung";
TANKADIN_IMMUNE             = "immun";
TANKADIN_IMMUNE_MESSAGE     = "Spott fehlgeschlagen! Das Ziel ist dagegen immun!";
TANKADIN_RESIST             = "widerstanden";
TANKADIN_RESIST_MESSAGE     = "Spott fehlgeschlagen! Das Ziel hat widerstanden!";
TANKADIN_AS                 = "Schild des R\195\164chers";
TANKADIN_MISS_AS            = "verfehlt";
TANKADIN_MISS_MESSAGE       = "Schild des R\195\164chers hat verfehlt!"
TANKADIN_BOS                = "Segen der Rettung";
TANKADIN_GBOS               = "Gro\195\159er Segen der Rettung";
TANKADIN_AD                 = "Unerm\195\188dlicher Verteidiger";
TANKADIN_SUM                = "Unerm\195\188dlicher Verteidiger reduzierte %d Schaden aus %d Gesamtschaden (%.2f%%), und verhinderte %d Tode.";
TANKADIN_HSD                = "Heiligschaden";
TANKADIN_DATA_DM            = "DM";
TANKADIN_DATA_DM_LONG       = "Schaden abgewehrt";
TANKADIN_DATA_DT            = "DT";
TANKADIN_DATA_DT_LONG       = "Schaden erlitten";
TANKADIN_DATA_DA            = "DA";
TANKADIN_DATA_DA_LONG       = "Tode abgewehrt";
TANKADIN_DATA_PERCENT       = "Prozent reduziert";
TANKADIN_USAGE              = "Anwendung: /tankadin <option>";
TANKADIN_TOOLTIP_TITLE      = "Tankadin";
TANKADIN_TOOLTIP_SUBTITLE   = "Paladin Tanking Mod";
TANKADIN_TOOLTIP_LOCKED     = "Die Fenster sind jetzt gesperrt.";
TANKADIN_TOOLTIP_LEFTCLICK  = "Linksklick und Ziehen um das Fenster zu verschieben.";
TANKADIN_TOOLTIP_MINMIZE    = "Rechtsklick um das Fenster zu minimieren/maximieren.";
TANKADIN_OPTIONS            = "Schaltet das Optionspanel ein/aus";
TANKADIN_OPTIONS_NAME       = "Optionen";
TANKADIN_OPTIONS_BASIC      = "Einfacher Tooltip";
TANKADIN_OPTIONS_ADVANCED   = "Erweiterter Tooltip";
TANKADIN_OPTIONS_SHOW       = "Zeigt das Optionsmen\195\188 an";
TANKADIN_OPTIONS_ANNOUNCE   = "Zeigt Unerm\195\188dlicher Vert. Infos im Chatfenster an";
TANKADIN_OPTIONS_MINIMIZE   = "Zeigt nur die Tankadin-Kopfzeile";
TANKADIN_OPTIONS_LOCK       = "Sperrt das Tankadin-Fenster in seiner momentanen Position";
TANKADIN_OPTIONS_WARN       = "Warnt wenn "..TANKADIN_RF.." schwindet"
TANKADIN_OPTIONS_ONCE       = "Blitzt einmal auf, wenn "..TANKADIN_RF.." schwindet";
TANKADIN_OPTIONS_ALWAYS     = "dauerhaftes Aufblitzen bis "..TANKADIN_RF.." erneuert wurde";
TANKADIN_OPTIONS_MISSRES    = "Warnt deine Gruppe wenn "..TANKADIN_RD.."\noder "..TANKADIN_AS.." fehlschl\195\164gt bzw. verfehlt";
TANKADIN_OPTIONS_NOIMMUNE   = "Deaktiviert den Alarm f\195\188r spottimmune Gegner";
TANKADIN_OPTIONS_ALPHA      = "Legt die Transparenz des Fensters fest";
TANKADIN_OPTIONS_ALPHALABEL = "Transparenz";
TANKADIN_OPTIONS_ALPHAWRONG = "Der Wert muss zwischen 0 und 1 sein";
TANKADIN_OPTIONS_SCALELABEL = "Skalierung";
TANKADIN_OPTIONS_DEFAULTS   = "Standard";
TANKADIN_OPTIONS_RESET_TB   = "zur\195\188cksetzen";
TANKADIN_OPTIONS_TITLE      = TANKADIN_TOOLTIP_TITLE.." "..TANKADIN_VERSION.." "..TANKADIN_OPTIONS_NAME;
TANKADIN_OPTIONS_LEFTCLICK  = "Linksklick und Ziehen um das Fenster zu verschieben.";
TANKADIN_OPTIONS_ADCLEAR    = "Setzt die Unerm\195\188dlicher Verteidiger Daten vor Kampfbeginn zur\195\188ck.";
TANKADIN_OPTIONS_DONE       = "Fertig";
TANKADIN_OPTIONS_TAB1       = "Basis";
TANKADIN_OPTIONS_TAB2       = "UV Tracker";
TANKADIN_OPTIONS_TAB3       = "Farben";
TANKADIN_OPTIONS_TAB4       = "Fenster";
TANKADIN_OPTIONS_TAB5       = "Warnungen";
TANKADIN_OPTIONS_TAB6       = "Credits";
TANKADIN_OPTIONS_BGCOLOR    = "Hintergrundfarbe";
TANKADIN_OPTIONS_FRAMECOLOR = "Fensterfarbe";
TANKADIN_OPTIONS_TCOLOR     = "Textfarbe";
TANKADIN_OPTIONS_WARNCOLOR  = "Farbe der Warnung";
TANKADIN_OPTIONS_FLASHWARN  = "Flash Fenster!";
TANKADIN_OPTIONS_WARNFRAMES = "Art der Warnung:";
TANKADIN_OPTIONS_RAD        = "UV Info";
TANKADIN_OPTIONS_RAD_S      = "Sende UV Info nach: ";
TANKADIN_OPTIONS_RISHORT    = "AT Info (Kurz)";
TANKADIN_OPTIONS_RISHORT_S  = "Sende verk\195\188rzte Angriffstabellen-Info nach: ";
TANKADIN_OPTIONS_RILONG     = "AT Info (Lang)";
TANKADIN_OPTIONS_RILONG_S   = "Sende erweiterte Angriffstabellen-Info nach: ";
TANKADIN_OPTIONS_REH        = "sende EH";
TANKADIN_OPTIONS_REH_S      = "sende effektives Leben an: ";
TANKADIN_OPTIONS_UNKOWN_S   = "unbekannte Anforderung...";
TANKADIN_OPTIONS_CHANNELS   = "-- Channels --";
TANKADIN_OPTIONS_C_DEF      = "Standard";
TANKADIN_OPTIONS_C_GUILD    = "Gilde";
TANKADIN_OPTIONS_C_WT       = "Ziel anfl\195\188stern";
TANKADIN_OPTIONS_C_CUSTOM   = "Eigener Channel";
TANKADIN_OPTIONS_GROWUP     = "Klappt das Fenster oberhalb der Tankadin-Kopfzeile aus.";
TANKADIN_OPTIONS_DEATHANN   = "Sagt an wenn Unerm\195\188dlicher Verteidiger einen Tod verhindert.";
TANKADIN_OPTIONS_DETACHAD   = "l\195\182se Unerm\195\188dlicher das Verteidiger Fenster.";
TANKADIN_OPTIONS_HIDEAD     = "verstecke das Unerm\195\188dlicher Verteidiger Fenster.";
TANKADIN_OPTIONS_DETACHRF   = "l\195\182se das Zorn der Gerechtigkeit Fenster.";
TANKADIN_OPTIONS_HIDERF     = "verstecke das Zorn der Gerechtigkeit Fenster.";
TANKADIN_OPTIONS_DETACHINFO = "l\195\182se das Infofenster.";
TANKADIN_OPTIONS_HIDEINFO   = "verstecke das Infofenster.";
TANKADIN_OPTIONS_HIDEHEADER = "Verstecke die Tankadin Kopfzeile und die angebrachten Fenster.";
TANKADIN_DEATHAVOID_MESSAGE = "Unerm\195\188dlicher Verteidiger -!!- Tod verhindert!";
TANKADIN_MESSAGE_UNLOCK     = "Tankadin-Fenster ist jetzt entsperrt.";
TANKADIN_MESSAGE_LOCK       = "Tankadin-Fenster ist jetzt gesperrt.";
TANKADIN_INFO_EH_BASE       = "Basiswert des effektiven Lebens";
TANKADIN_INFO_EH_MAX        = "(10k Schaden) effektives Leben";
TANKADIN_INFO_EH_MIN        = "(3k Schaden) effektives Leben";
TANKADIN_INFO_EH_TDR        = "gesamte Schadensreduzierung";
TANKADIN_AD_HP_ACTIVE       = "Unerm\195\188dlicher Verteidiger wird aktiv bei";
TANKADIN_AD_HP_ABBR         = "Lebenspunkten";
TANKADIN_IN_COMBAT_ERROR    = "Das geht nicht, da du im Kampf bist.";
TANKADIN_VERSION_UPDATE     = "Deine Tankadin-Version wurde geupdatet zu "..TANKADIN_VERSION.." und die Standardeinstellungen wurden geladen.";
TANKADIN_PLUGINSTRING       = "momentan installierte Plug-ins:";
TANKADIN_ADDON_DISABLED     = "Tankadin deaktiviert";

end

-- English (Great Britain)
if ( GetLocale() == "enGB") then

end

-- Spanish
if ( GetLocale() == "esES") then

end

-- French
if ( GetLocale() == "frFR") then
   TANKADIN_MISS               = "Rat\195\169";
   TANKADIN_DODGE              = "Esquive";
   TANKADIN_PARRY              = "Parade";
   TANKADIN_BLOCK              = "Blocage";
   TANKADIN_TOTAL              = "Avoidance";
   TANKADIN_UPDOWN             = "+/-";
   TANKADIN_CRUSHING           = "Ecrasants";
   TANKADIN_BVALUE             = "Bloquer";
   TANKADIN_DEFENSE            = "D\195\169fense";
   TANKADIN_RF                 = "Fureur vertueuse";
   TANKADIN_RF_FADE            = "Fureur vertueuse dispara\195\174t"
   TANKADIN_RD                 = "D\195\169fense vertueuse";
   TANKADIN_IMMUNE             = "immunis\195\169";
   TANKADIN_IMMUNE_MESSAGE     = "Provocation \195\169chou\195\169e! La cible est immunis\195\169e!";
   TANKADIN_RESIST             = "r\195\169siste";
   TANKADIN_RESIST_MESSAGE     = "Provocation \195\169chou\195\169e! La cible a r\195\169sist\195\169";
   TANKADIN_AS                 = "Bouclier du vengeur";
   TANKADIN_MISS_AS            = "rat\195\169";
   TANKADIN_MISS_MESSAGE       = "Le Bouclier du vengeur a rat\195\169!"
   TANKADIN_BOS                = "B\195\169n\195\169diction de salut";
   TANKADIN_GBOS               = "B\195\169n\195\169diction de salut sup\195\169rieure";
   TANKADIN_AD                 = "Ardent d\195\169fenseur";
   TANKADIN_SUM                = "Ardent d\195\169fenseur a absorb\195\169 %d d\195\169g\195\162ts sur un total de %d d\195\169g\195\162ts re\195\167us (%.2f%%), et a repouss\195\169 %d morts.";
   TANKADIN_HSD                = "DDS sacr\195\169";
   TANKADIN_DATA_DM            = "DA";
   TANKADIN_DATA_DM_LONG       = "D\195\169g\195\162ts absorb\195\169s";
   TANKADIN_DATA_DT            = "DR";
   TANKADIN_DATA_DT_LONG       = "D\195\169g\195\162ts re\195\167us";
   TANKADIN_DATA_DA            = "ME";
   TANKADIN_DATA_DA_LONG       = "Morts \195\169vit\195\169es";
   TANKADIN_DATA_PERCENT       = "Pourcentage de r\195\169duction";
   TANKADIN_USAGE              = "Utilisation: /tankadin <option>";
   TANKADIN_TOOLTIP_TITLE      = "Tankadin";
   TANKADIN_TOOLTIP_SUBTITLE   = "Pally Tanking Mod";
   TANKADIN_TOOLTIP_LOCKED     = "Les fen\195\170tres sont bloqu\195\169es";
   TANKADIN_TOOLTIP_LEFTCLICK  = "Cliquer gauche et maintenir pour d\195\169placer la fen\195\170tre";
   TANKADIN_TOOLTIP_MINMIZE    = "Clic droit pour afficher ou cacher la fen\195\170tre";
   TANKADIN_OPTIONS            = "Ouvre/ferme la fen\195\170tre d'options";
   TANKADIN_OPTIONS_NAME       = "Options";
   TANKADIN_OPTIONS_BASIC      = "R\195\169sum\195\169 court";
   TANKADIN_OPTIONS_ADVANCED   = "R\195\169sum\195\169 long";
   TANKADIN_OPTIONS_SHOW       = "Afficher la fen\195\170tre principale";
   TANKADIN_OPTIONS_ANNOUNCE   = "Annoncer les infos du suivi d'Ardent D\195\169fenseur";
   TANKADIN_OPTIONS_MINIMIZE   = "Afficher uniquement le header";
   TANKADIN_OPTIONS_LOCK       = "Bloquer la fen\195\170tre de Tankadin et des options";
   TANKADIN_OPTIONS_WARN       = "Avertir quand "..TANKADIN_RF.." dispara\195\174t";
   TANKADIN_OPTIONS_ONCE       = "Flash une fois lorsque "..TANKADIN_RF.." dispara\195\174t";
   TANKADIN_OPTIONS_ALWAYS     = "Flash jusqu'\195\160 ce que "..TANKADIN_RF.." soit relanc\195\169";
   TANKADIN_OPTIONS_MISSRES    = "Alerter le raid ou le groupe lorsque "..TANKADIN_RD.."\n\195\169choue ou que le "..TANKADIN_AS.." rate";
   TANKADIN_OPTIONS_NOIMMUNE   = "D\195\169sactiver les alertes pour les immunit\195\169s";
   TANKADIN_OPTIONS_ALPHA      = "D\195\169finit la transparence de la fen\195\170tre";
   TANKADIN_OPTIONS_ALPHALABEL = "Transparence";
   TANKADIN_OPTIONS_ALPHAWRONG = "La transparence doit \195\170tre comprise entre 0 et 1";
   TANKADIN_OPTIONS_SCALELABEL = "Echelle";
   TANKADIN_OPTIONS_DEFAULTS   = "Par d\195\169faut";
   TANKADIN_OPTIONS_RESET_TB   = "Options par d\195\169faut";
   TANKADIN_OPTIONS_TITLE      = TANKADIN_TOOLTIP_TITLE.." "..TANKADIN_VERSION.." "..TANKADIN_OPTIONS_NAME;
   TANKADIN_OPTIONS_LEFTCLICK  = "Cliquer gauche et maintenir pour d\195\169placer la fen\195\170tre";
   TANKADIN_OPTIONS_ADCLEAR    = "Effacer les donn\195\169es d'Ardent D\195\169fenseur \195\160 chaque combat";
   TANKADIN_OPTIONS_DONE       = "Termin\195\169";
   TANKADIN_OPTIONS_TAB1       = "G\195\169n\195\169ral";
   TANKADIN_OPTIONS_TAB2       = "Suivi AD";
   TANKADIN_OPTIONS_TAB3       = "Couleurs";
   TANKADIN_OPTIONS_TAB4       = "Fen\195\170tres";
   TANKADIN_OPTIONS_TAB5       = "Annonces";
   TANKADIN_OPTIONS_TAB6       = "Credits";
   TANKADIN_OPTIONS_BGCOLOR    = "Couleur du fond";
   TANKADIN_OPTIONS_FRAMECOLOR = "Couleur des bordures";
   TANKADIN_OPTIONS_TCOLOR     = "Couleur du texte";
   TANKADIN_OPTIONS_WARNCOLOR  = "Couleur de l'avertissement";
   TANKADIN_OPTIONS_FLASHWARN  = "Flash avertissement";
   TANKADIN_OPTIONS_WARNFRAMES = "Image d'avertissement:";
   TANKADIN_OPTIONS_RAD        = "Rapport AD";
   TANKADIN_OPTIONS_RAD_S      = "Rendre le rapport d'Ardent D\195\169fenseur dans: ";
   TANKADIN_OPTIONS_RISHORT    = "Rapport info (C)";
   TANKADIN_OPTIONS_RISHORT_S  = "Rendre le rapport de la table d'attaque abr\195\169g\195\169e dans: ";
   TANKADIN_OPTIONS_RILONG     = "Rapport info (L)";
   TANKADIN_OPTIONS_RILONG_S   = "Rendre le rapport de la table d'attaque \195\169tendue dans: ";
   TANKADIN_OPTIONS_UNKOWN_S   = "Requ\195\170te inconnue...";
   TANKADIN_OPTIONS_CHANNELS   = "-- Canal --";
   TANKADIN_OPTIONS_C_DEF      = "D\195\169faut";
   TANKADIN_OPTIONS_C_GUILD    = "Guilde";
   TANKADIN_OPTIONS_C_WT       = "Chuchoter \195\160 la cible";
   TANKADIN_OPTIONS_C_CUSTOM   = "Canal personnalis\195\169";
   TANKADIN_OPTIONS_GROWUP     = "Faire d\195\169filer les fen\195\170tres vers le haut du header";
   TANKADIN_OPTIONS_DEATHANN   = "Annoncer quand Ardent D\195\169fenseur permet d'\195\169viter une mort";
   TANKADIN_OPTIONS_DETACHAD   = "D\195\169tacher la fen\195\170tre d'AD";
   TANKADIN_OPTIONS_HIDEAD     = "Cacher la fen\195\170tre d'AD";
   TANKADIN_OPTIONS_DETACHRF   = "D\195\169tacher la fen\195\170tre de FV";
   TANKADIN_OPTIONS_HIDERF     = "Cacher la fen\195\170tre de FV";
   TANKADIN_OPTIONS_DETACHINFO = "D\195\169tacher la fen\195\170tre d'infos";
   TANKADIN_OPTIONS_HIDEINFO   = "Cacher la fen\195\170tre d'infos";
   TANKADIN_OPTIONS_HIDEHEADER = "Cacher le header et les fen\195\170tres rattach\195\169es";
   TANKADIN_DEATHAVOID_MESSAGE = "Ardent d\195\169fenseur -!!- Mort �vit\195\169e!";
   TANKADIN_MESSAGE_UNLOCK     = "La fen\195\170tre de Tankadin est maintenant d\195\169bloqu\195\169e";
   TANKADIN_MESSAGE_LOCK       = "La fen\195\170tre de Tankadin est maintenant bloqu\195\169e";
   TANKADIN_INFO_EH_BASE       = "Vie effective (base)";
   TANKADIN_INFO_EH_MAX        = "Vie effective (3k)";
   TANKADIN_INFO_EH_MIN        = "Vie effective (10k)";
   TANKADIN_AD_HP_ACTIVE       = "Ardent d\195\169fenseur est actif \195\160";
   TANKADIN_AD_HP_ABBR         = "PV";
   TANKADIN_IN_COMBAT_ERROR    = "Vous ne pouvez pas faire \195\167a en combat";
   TANKADIN_VERSION_UPDATE     = "Votre version de Tankadin a \195\169t\195\169 mise � jour vers "..TANKADIN_VERSION.." et les param\195\168tres ont \195\169t\195\169 r\195\169initialis\195\169s";
   TANKADIN_PLUGINSTRING       = "Plug-ins actuellement install\195\169s:";
   TANKADIN_ADDON_DISABLED     = "Tankadin d\195\169sactiv\195\169";
   
end 


--Korean
if ( GetLocale() == "koKR") then

end

-- Simplified Chinese
if ( GetLocale() == "zhCN") then

end

--Traditional Chinese
if ( GetLocale() == "zhTW") then

end